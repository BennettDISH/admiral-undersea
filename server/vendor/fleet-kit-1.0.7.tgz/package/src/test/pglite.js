// An in-memory Postgres for an app's tests (PGlite), with no database to install.
//
// A new PGlite costs about 10 CPU-seconds in a cold process, nearly all of it initdb, and every
// test file starts one: the first to start saves its fresh data directory in the temp folder,
// keyed by the PGlite and Node versions, and the rest load it, about a sixth of the cost. A
// missing, half-written or unreadable template just means a cold start. A PGlite loaded that way
// keeps the process from ending until it is closed: close() it at the end.
//
//   const db = await createPglite();            // a PGlite
//   const pool = pglitePool(db);                // pg Pool-like: query(sql, params), connect() -> client
//   const { url, stop } = await startPgliteServer();   // a postgres:// URL for a spawned server
//                                               // (needs @electric-sql/pglite-socket)
import { readFile, rename, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import os from 'node:os';
import path from 'node:path';
import { PGlite } from '@electric-sql/pglite';

const requireHere = createRequire(import.meta.url);

async function templateFile(name) {
  // (the package does not export its package.json, so it is found from the entry file in dist/)
  const entry = requireHere.resolve('@electric-sql/pglite');
  const { version } = JSON.parse(await readFile(path.join(path.dirname(entry), '..', 'package.json'), 'utf8'));
  return path.join(os.tmpdir(), `${name}-pglite-${version}-node${process.versions.node.split('.')[0]}.tar`);
}

/** A fresh, empty PGlite, from the cached template when there is one. `name` keys the template
 *  file (one per app keeps two apps' versions apart). */
export async function createPglite({ name = 'fleet-kit' } = {}) {
  let file;
  try {
    file = await templateFile(name);
  } catch {
    return PGlite.create();
  }
  try {
    return await PGlite.create({ loadDataDir: new Blob([await readFile(file)]) });
  } catch {
    // no template yet, or one that would not load
  }
  const db = await PGlite.create();
  try {
    const tmp = `${file}.${process.pid}.tmp`;
    await writeFile(tmp, Buffer.from(await (await db.dumpDataDir('none')).arrayBuffer()));
    await rename(tmp, file); // whole or not there at all, whichever file reads it
  } catch {
    // the template is an optimisation
  }
  return db;
}

/** A pg Pool's shape over one PGlite: query(sql, params) answers { rows, rowCount } (a query
 *  with no parameters may hold several statements, as pg's simple protocol allows), and
 *  connect() gives a client whose release() does nothing. PGlite is one session, so a
 *  transaction on the "client" is the database's one transaction: tests run one at a time. */
export function pglitePool(db) {
  const query = async (sql, params) => {
    if (params && params.length) {
      const r = await db.query(sql, params);
      return { rows: r.rows, rowCount: r.affectedRows ?? r.rows.length };
    }
    const all = await db.exec(sql);
    const last = all[all.length - 1] ?? { rows: [] };
    return { rows: last.rows, rowCount: last.affectedRows ?? last.rows.length };
  };
  return {
    query,
    connect: async () => ({ query, release() {} }),
    end: async () => {},
  };
}

/** PGlite behind its wire-protocol server, for a server under test that connects with pg: a
 *  postgres:// URL and stop(). */
export async function startPgliteServer({ name, port = 20000 + Math.floor(Math.random() * 20000) } = {}) {
  const { PGLiteSocketServer } = await import('@electric-sql/pglite-socket');
  const db = await createPglite({ name });
  const server = new PGLiteSocketServer({ db, port, host: '127.0.0.1', maxConnections: 16 });
  await server.start();
  return {
    db,
    url: `postgres://postgres@127.0.0.1:${port}/postgres`,
    stop: async () => {
      await server.stop().catch(() => {});
      await new Promise((r) => setTimeout(r, 100));
      await db.close().catch(() => {});
    },
  };
}
