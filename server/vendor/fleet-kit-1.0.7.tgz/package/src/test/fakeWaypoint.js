// A stand-in for Waypoint on a local port, for an app's tests: the authorize redirect, the code
// exchange, the proxy routes (guest, login, register, claim, seen, guests) and /logout.
//
//   const wp = await startFakeWaypoint();          wp.url, wp.env() (AUTH_SERVICE_URL, SSO_CLIENT_ID, SSO_CLIENT_SECRET)
//   wp.addUser({ username, password, email })      an account; answers its central id
//   wp.signInAs(id | { username, is_guest })       who the next authorize redirect signs in as
//   wp.set({ claimed, gone, unknown })             what proxy/guests says of ids (default: an unclaimed guest)
//   wp.status = 500 | ...                          answers that status to everything
//   wp.delay = ms                                  holds every answer back
//   wp.answer(path, (body) => [status, json])      answers one POST route its own way (a misbehaving Waypoint)
//   wp.requests                                    [{ method, path, body, query }] it was sent
//   wp.reset(); await wp.close()
import http from 'node:http';
import crypto from 'node:crypto';

const WORDS = ['swift', 'quiet', 'amber', 'brave', 'otter', 'heron', 'maple', 'cedar'];

export async function startFakeWaypoint({ clientId = 'test-client', clientSecret = 'test-secret', firstId = 1000 } = {}) {
  const w = {
    requests: [],
    status: null,
    delay: 0,
    users: new Map(), // id -> { central_user_id, username, email, first_name, last_name, is_guest, password }
    codes: new Map(), // code -> { id, redirect_uri }
    claimed: new Set(),
    gone: new Set(),
    unknown: new Set(),
    seen: [],
    nextId: firstId,
    nextSignIn: null,
    answers: new Map(), // path -> (body) => [status, json]
  };
  const info = (u) => ({ central_user_id: u.central_user_id, username: u.username, email: u.email ?? null, first_name: u.first_name ?? '', last_name: u.last_name ?? '', is_guest: Boolean(u.is_guest) });
  w.addUser = ({ username, password = 'pw', email = null, is_guest = false, first_name = '', last_name = '', central_user_id } = {}) => {
    const id = central_user_id ?? w.nextId++;
    w.users.set(id, { central_user_id: id, username: username ?? (is_guest ? guestName() : `user${id}`), password, email, is_guest, first_name, last_name });
    return id;
  };
  const guestName = () => `guest-${WORDS[crypto.randomInt(WORDS.length)]}-${WORDS[crypto.randomInt(WORDS.length)]}-${String(crypto.randomInt(10000)).padStart(4, '0')}`;
  w.signInAs = (who) => {
    w.nextSignIn = typeof who === 'object' && who !== null ? w.addUser(who) : who;
    return w.nextSignIn;
  };
  w.set = ({ claimed = [], gone = [], unknown = [] } = {}) => {
    w.claimed = new Set(claimed.map(String));
    w.gone = new Set(gone.map(String));
    w.unknown = new Set(unknown.map(String));
  };
  w.answer = (path, fn) => w.answers.set(path, fn);
  w.reset = () => {
    w.answers.clear();
    w.requests.length = 0;
    w.status = null;
    w.delay = 0;
    w.seen.length = 0;
    w.nextSignIn = null;
    w.set();
  };

  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      const url = new URL(req.url, 'http://fake');
      const send = (code, body, headers = {}) => setTimeout(() => {
        res.writeHead(code, { 'Content-Type': 'application/json', ...headers });
        res.end(body === undefined ? '' : JSON.stringify(body));
      }, w.delay);
      let body = null;
      if (raw) {
        try { body = JSON.parse(raw); } catch { return send(400, { error: 'bad json' }); }
      }
      w.requests.push({ method: req.method, path: url.pathname, body, query: Object.fromEntries(url.searchParams) });
      if (w.status) return send(w.status, { error: 'stand-in failure' });

      if (req.method === 'GET' && url.pathname === '/oauth/authorize') {
        if (url.searchParams.get('client_id') !== clientId) return send(400, { error: 'unknown client' });
        const id = w.nextSignIn ?? w.addUser({});
        w.nextSignIn = null;
        const code = crypto.randomBytes(12).toString('hex');
        w.codes.set(code, { id, redirect_uri: url.searchParams.get('redirect_uri') });
        const back = new URL(url.searchParams.get('redirect_uri'));
        back.searchParams.set('code', code);
        back.searchParams.set('state', url.searchParams.get('state') ?? '');
        return send(302, undefined, { Location: back.toString() });
      }
      if (req.method === 'GET' && url.pathname === '/logout') {
        const to = url.searchParams.get('return_to');
        return to ? send(302, undefined, { Location: to }) : send(200, { signedOut: true });
      }
      if (req.method !== 'POST') return send(404, { error: 'Not found' });
      if (body?.client_id !== clientId || body?.client_secret !== clientSecret) return send(401, { error: 'Invalid client credentials' });
      if (w.answers.has(url.pathname)) {
        const [code, json] = w.answers.get(url.pathname)(body);
        return send(code, json);
      }

      switch (url.pathname) {
        case '/oauth/token': {
          const got = w.codes.get(body.code);
          w.codes.delete(body.code); // one use
          if (body.grant_type !== 'authorization_code' || !got) return send(400, { error: 'invalid_grant' });
          if (body.redirect_uri && body.redirect_uri !== got.redirect_uri) return send(400, { error: 'redirect_uri mismatch' });
          return send(200, info(w.users.get(got.id)));
        }
        case '/api/auth/proxy/guest': {
          const id = w.addUser({ is_guest: true });
          return send(201, info(w.users.get(id)));
        }
        case '/api/auth/proxy/login': {
          const u = [...w.users.values()].find((x) => (x.username === body.email || x.email === body.email) && x.password === body.password && !x.is_guest);
          return u ? send(200, info(u)) : send(401, { error: 'Invalid credentials' });
        }
        case '/api/auth/proxy/register': {
          if ([...w.users.values()].some((x) => x.username === body.username)) return send(409, { error: 'That username is taken' });
          const id = w.addUser({ username: body.username, password: body.password, email: body.email, first_name: body.first_name ?? '', last_name: body.last_name ?? '' });
          return send(201, { ...info(w.users.get(id)), recovery_code: 'RECOVER-ME' });
        }
        case '/api/auth/proxy/claim': {
          const u = w.users.get(Number(body.central_user_id));
          if (!u) return send(404, { error: 'No such guest' });
          if (!u.is_guest) return send(409, { error: 'Already kept' });
          Object.assign(u, { username: body.username, password: body.password, email: body.email ?? null, is_guest: false });
          return send(200, { ...info(u), recovery_code: 'RECOVER-ME' });
        }
        case '/api/auth/proxy/seen':
          w.seen.push(body.central_user_id);
          return send(200, { ok: true });
        case '/api/auth/proxy/guests': {
          if (!Array.isArray(body.ids) || body.ids.length < 1 || body.ids.length > 500) return send(400, { error: 'ids must be a list of 1 to 500 central user ids' });
          const out = { guests: [], claimed: [], gone: [], unknown: [] };
          for (const id of body.ids) {
            const key = String(id);
            out[w.claimed.has(key) ? 'claimed' : w.gone.has(key) ? 'gone' : w.unknown.has(key) ? 'unknown' : 'guests'].push(id);
          }
          return send(200, out);
        }
        default:
          return send(404, { error: 'Not found' });
      }
    });
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  w.url = `http://127.0.0.1:${server.address().port}`;
  w.env = () => ({ AUTH_SERVICE_URL: w.url, SSO_CLIENT_ID: clientId, SSO_CLIENT_SECRET: clientSecret });
  w.close = () => new Promise((resolve) => {
    server.closeAllConnections?.();
    server.close(resolve);
  });
  return w;
}
