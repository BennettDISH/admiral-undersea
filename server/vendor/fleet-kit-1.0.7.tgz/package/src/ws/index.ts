/**
 * WebSocket limits for the real-time games: who a socket is (its address and the per-address
 * key), how many sockets one address may hold, how fast one socket may send, how many malformed
 * frames it gets, how many wrong guesses (room codes, invite words) an address gets, the Origin
 * check at the upgrade, and the heartbeat that drops half-open sockets and ones too far behind.
 *
 * Nothing here imports `ws`: every socket and server is the slice of it these use, so a test
 * drives a fake. Per-socket limits reset with each new socket, which is why the counts that
 * matter (sockets, guesses) are per address.
 */
import { ipKey as serverIpKey } from '../../src/server/limits.js';
import { originAllowed as serverOriginAllowed } from '../../src/server/sameOrigin.js';

export interface UpgradeRequest {
  headers: Record<string, string | string[] | undefined>;
  socket?: { remoteAddress?: string | undefined } | null;
}

const unmap = (ip: string): string => /^::ffff:(\d+\.\d+\.\d+\.\d+)$/i.exec(ip)?.[1] ?? ip;

/**
 * The browser's address for an upgrade request, read the way Express reads req.ip with `trust
 * proxy` set to `hops`: X-Forwarded-For from the right, `hops` entries in. With 1 (the fleet's
 * setting) that is the last entry, the one the platform's edge adds and a client cannot write.
 * 0 is the socket peer. The upgrade never passes through Express, so its setting does not apply.
 */
export function clientIp(req: UpgradeRequest, { hops = 1 }: { hops?: number } = {}): string {
  const peer = unmap(req.socket?.remoteAddress ?? 'unknown');
  if (hops <= 0) return peer;
  const header = req.headers['x-forwarded-for'];
  const forwarded = (Array.isArray(header) ? header.join(',') : header ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const nearestFirst = [peer, ...forwarded.reverse()];
  return unmap(nearestFirst[Math.min(hops, nearestFirst.length - 1)] ?? peer);
}

/** The key per-address limits count under: IPv4 itself, IPv6 by its /64. */
export const ipKey: (ip: string) => string = serverIpKey;

/** The Origin check for the upgrade: our own pages only (see server/sameOrigin.js). */
export const originAllowed: (req: UpgradeRequest, opts?: { baseUrl?: string; env?: Record<string, string | undefined> }) => boolean = serverOriginAllowed;

/** Open sockets per address. Generous on purpose: a household or a classroom shares one. */
export class SocketLimits {
  private readonly open_ = new Map<string, number>();
  constructor(private readonly opts: { maxPerKey: number }) {}

  /** Whether `key` may open one more. */
  allows(key: string): boolean {
    return (this.open_.get(key) ?? 0) < this.opts.maxPerKey;
  }

  /** Takes a slot for `key`; false (nothing taken) when it already holds its cap. */
  open(key: string): boolean {
    const n = this.open_.get(key) ?? 0;
    if (n >= this.opts.maxPerKey) return false;
    this.open_.set(key, n + 1);
    return true;
  }

  close(key: string): void {
    const n = (this.open_.get(key) ?? 0) - 1;
    if (n > 0) this.open_.set(key, n);
    else this.open_.delete(key);
  }

  count(key: string): number {
    return this.open_.get(key) ?? 0;
  }
}

/** One socket's message rate, whatever the types: a token bucket of `burst`, refilled at
 *  `perSec`. Real play stays far below it; past it the caller drops the frame or closes. */
export class FrameBudget {
  private tokens: number;
  private at: number;
  constructor(private readonly opts: { perSec: number; burst: number; now?: () => number }) {
    this.tokens = opts.burst;
    this.at = (opts.now ?? Date.now)();
  }

  take(): boolean {
    const now = (this.opts.now ?? Date.now)();
    this.tokens = Math.min(this.opts.burst, this.tokens + ((now - this.at) * this.opts.perSec) / 1000);
    this.at = now;
    if (this.tokens < 1) return false;
    this.tokens -= 1;
    return true;
  }
}

/** A sliding count in a window: `add()` counts one and says whether `max` is now reached (bad
 *  frames: close the socket). */
export class WindowCount {
  private times: number[] = [];
  constructor(private readonly opts: { max: number; windowMs: number; now?: () => number }) {}

  add(): boolean {
    const now = (this.opts.now ?? Date.now)();
    this.times = this.times.filter((t) => now - t < this.opts.windowMs);
    this.times.push(now);
    return this.times.length >= this.opts.max;
  }

  get size(): number {
    const now = (this.opts.now ?? Date.now)();
    return this.times.filter((t) => now - t < this.opts.windowMs).length;
  }
}

/**
 * Wrong guesses per address (a room code, an invite word). Past `max` misses in the window,
 * every guess from that address waits the window out, right ones included, so guessing cannot go
 * on between them; and the answer is the same for every code, so it learns nothing. Right
 * guesses never count: a party on one network all joining by the code is nobody's miss.
 */
export class Misses {
  private readonly misses = new Map<string, { count: number; until: number }>();
  constructor(private readonly opts: { max: number; windowMs: number; now?: () => number; maxKeys?: number }) {}

  private live(key: string, now: number) {
    const h = this.misses.get(key);
    return h && h.until > now ? h : null;
  }

  blocked(key: string): boolean {
    return (this.live(key, (this.opts.now ?? Date.now)())?.count ?? 0) >= this.opts.max;
  }

  /** Seconds until `key` may guess again (0 when it may now). */
  retryAfter(key: string): number {
    const now = (this.opts.now ?? Date.now)();
    const h = this.live(key, now);
    return h && h.count >= this.opts.max ? Math.ceil((h.until - now) / 1000) : 0;
  }

  miss(key: string): void {
    const now = (this.opts.now ?? Date.now)();
    const h = this.live(key, now) ?? { count: 0, until: now + this.opts.windowMs };
    h.count += 1;
    this.misses.set(key, h);
    if (this.misses.size > (this.opts.maxKeys ?? 10000)) {
      for (const [k, v] of this.misses) if (v.until <= now) this.misses.delete(k);
    }
  }
}

/** The slice of a ws socket these use. */
export interface LiveSocket {
  readonly readyState: number;
  readonly bufferedAmount?: number;
  ping(): void;
  terminate(): void;
  on(event: 'pong' | 'close', listener: () => void): unknown;
}

/** The slice of a ws server these use. */
export interface SocketServer<S extends LiveSocket = LiveSocket> {
  readonly clients: Iterable<S>;
  on(event: 'connection', listener: (socket: S, req: UpgradeRequest) => void): unknown;
  on(event: 'close', listener: () => void): unknown;
}

export const WS_OPEN = 1;

/**
 * Drops half-open sockets (an ungraceful disconnect that never fires 'close', so its player
 * would linger as a ghost) and ones whose unsent backlog passed `maxBufferedBytes` (a client
 * that stopped reading). Every `intervalMs`, a socket that did not answer the last ping is
 * terminated (which fires 'close', and the app's own cleanup); the rest are pinged. The timer
 * never keeps the process up. Returns a stop function.
 */
export function keepAlive<S extends LiveSocket>(server: SocketServer<S>, { intervalMs = 30_000, maxBufferedBytes = 1 << 20 }: { intervalMs?: number; maxBufferedBytes?: number } = {}): () => void {
  const alive = new WeakMap<S, boolean>();
  server.on('connection', (socket) => {
    alive.set(socket, true);
    socket.on('pong', () => alive.set(socket, true));
  });
  const timer = setInterval(() => {
    for (const socket of server.clients) {
      if (alive.get(socket) === false || (socket.bufferedAmount ?? 0) > maxBufferedBytes) {
        try {
          socket.terminate();
        } catch {
          /* already gone */
        }
        continue;
      }
      alive.set(socket, false);
      if (socket.readyState === WS_OPEN) {
        try {
          socket.ping();
        } catch {
          /* the next round terminates it */
        }
      }
    }
  }, intervalMs);
  (timer as { unref?: () => void }).unref?.();
  const stop = () => clearInterval(timer);
  server.on('close', stop);
  return stop;
}

/**
 * The ws server's verifyClient: our own pages only (403), and a cap on open sockets per address
 * (429), checked at the upgrade so a refused socket never exists. Pair it with trackSocket on
 * 'connection', which holds the slot while the socket is open.
 */
export function admitSocket({ limits, hops = 1, origin = {} }: { limits?: SocketLimits; hops?: number; origin?: { baseUrl?: string; env?: Record<string, string | undefined> } } = {}) {
  return (info: { req: UpgradeRequest }, done: (ok: boolean, code?: number, message?: string) => void): void => {
    if (!originAllowed(info.req, origin)) return done(false, 403, 'Forbidden origin');
    if (limits && !limits.allows(ipKey(clientIp(info.req, { hops })))) return done(false, 429, 'Too many connections');
    done(true);
  };
}

/** Holds a socket slot for its address until the socket closes. Returns the key it counts
 *  under, or null when the address is at its cap (close the socket: 1008 or the app's code). */
export function trackSocket(socket: { on(event: 'close', listener: () => void): unknown }, req: UpgradeRequest, limits: SocketLimits, { hops = 1 }: { hops?: number } = {}): string | null {
  const key = ipKey(clientIp(req, { hops }));
  if (!limits.open(key)) return null;
  socket.on('close', () => limits.close(key));
  return key;
}

/**
 * One text frame as a command object: valid JSON, an object (not null, an array or a number),
 * with a string `typeKey` field, and at most `maxBytes`. Anything else is null, for the caller
 * to count as a bad frame.
 */
export function parseFrame(raw: unknown, { maxBytes = 64 * 1024, typeKey = 'type' }: { maxBytes?: number; typeKey?: string } = {}): Record<string, unknown> | null {
  let text: string;
  if (typeof raw === 'string') text = raw;
  else if (Buffer.isBuffer(raw)) text = raw.toString('utf8');
  else if (Array.isArray(raw)) text = Buffer.concat(raw as Buffer[]).toString('utf8');
  else if (raw instanceof ArrayBuffer) text = Buffer.from(raw).toString('utf8');
  else return null;
  if (Buffer.byteLength(text, 'utf8') > maxBytes) return null;
  let msg: unknown;
  try {
    msg = JSON.parse(text);
  } catch {
    return null;
  }
  if (!msg || typeof msg !== 'object' || Array.isArray(msg)) return null;
  return typeof (msg as Record<string, unknown>)[typeKey] === 'string' ? (msg as Record<string, unknown>) : null;
}
