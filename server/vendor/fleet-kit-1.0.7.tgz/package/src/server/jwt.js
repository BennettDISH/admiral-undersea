// HS256 JSON Web Tokens with node:crypto, so the kit needs no jsonwebtoken. The tokens are
// the same as jsonwebtoken's: a session an app minted with it before adopting the kit still
// verifies here with the same secret, and nobody is signed out by the swap.
import crypto from 'node:crypto';

const b64 = (value) => Buffer.from(typeof value === 'string' ? value : JSON.stringify(value)).toString('base64url');
const HEADER = b64({ alg: 'HS256', typ: 'JWT' });
const sign = (data, secret) => crypto.createHmac('sha256', secret).update(data).digest();

/** A signed token for `claims`, with iat and, given `ttlMs`, exp (both in seconds). */
export function signJwt(claims, secret, { ttlMs, now = Date.now() } = {}) {
  if (!secret) throw new Error('signJwt needs a secret');
  const iat = Math.floor(now / 1000);
  const body = { ...claims, iat, ...(ttlMs ? { exp: iat + Math.floor(ttlMs / 1000) } : {}) };
  const data = `${HEADER}.${b64(body)}`;
  return `${data}.${sign(data, secret).toString('base64url')}`;
}

/** The claims of a token whose signature holds and whose exp has not passed, else null.
 *  Only HS256 is taken: a token naming any other algorithm (none included) is refused. */
export function verifyJwt(token, secret, { now = Date.now() } = {}) {
  if (typeof token !== 'string' || !secret) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [h, p, s] = parts;
  try {
    if (JSON.parse(Buffer.from(h, 'base64url').toString('utf8'))?.alg !== 'HS256') return null;
  } catch {
    return null;
  }
  const want = sign(`${h}.${p}`, secret);
  const got = Buffer.from(s, 'base64url');
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return null;
  let claims;
  try {
    claims = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (!claims || typeof claims !== 'object' || Array.isArray(claims)) return null;
  if (claims.exp !== undefined && !(typeof claims.exp === 'number' && claims.exp * 1000 > now)) return null;
  if (typeof claims.nbf === 'number' && claims.nbf * 1000 > now) return null;
  return claims;
}
