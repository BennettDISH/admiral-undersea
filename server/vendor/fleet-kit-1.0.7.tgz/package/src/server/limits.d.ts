export declare function ipKey(ip: string): string;
export declare function clientKey(req: { ip?: string; socket?: { remoteAddress?: string } }): string;
export interface LimiterHit {
  ok: boolean;
  retryAfter: number;
  undo(): void;
}
export declare function limiter(opts: { windowMs: number; max: number; maxKeys?: number; now?: () => number }): {
  hit(key: string): LimiterHit;
  size(): number;
};
export declare function rateLimit(opts: {
  windowMs: number;
  max: number;
  message?: string;
  key?: (req: any) => string;
  onLimit?: (req: any, res: any) => unknown;
  maxKeys?: number;
}): (req: any, res: any, next: (err?: unknown) => void) => unknown;
export declare function budget(windowMs: number, max: number, opts?: { now?: () => number }): {
  max: number;
  room(key: string): number;
  add(key: string, n: number): void;
  resetIn(key: string): number;
};
export declare function trustOneProxy<A extends { set(name: string, value: unknown): unknown }>(app: A): A;
export declare function assertTrustProxy(app: { get(name: string): unknown }): void;
