// Cloudflare R2 through the S3 API. Configured entirely by env: R2_ACCOUNT_ID, R2_ACCESS_KEY_ID,
// R2_SECRET_ACCESS_KEY, R2_BUCKET, and R2_PUBLIC_URL for a public bucket. With any of them
// missing the store is null: the app answers 503 and shows no upload control, so nothing ever
// lands in the database instead (the database keeps only the object's key).
//
// Every call has a 15 s time limit, so a bucket that stops answering cannot hold a request (or a
// timer) open for good; a streamed object is destroyed when the browser goes away. Keys are
// random and never reused, so every object may be cached for good: privately (a private bucket
// the app streams behind its own checks) or publicly (a public bucket's address).
//
// Needs @aws-sdk/client-s3 in the app (an optional peer): import this from 'fleet-kit/server/r2'.
import crypto from 'node:crypto';
import {
  S3Client, PutObjectCommand, GetObjectCommand, HeadObjectCommand, CopyObjectCommand, DeleteObjectCommand,
  DeleteObjectsCommand, ListObjectsV2Command,
} from '@aws-sdk/client-s3';

export const R2_TIMEOUT_MS = 15_000;
export const PRIVATE_CACHE = 'private, max-age=31536000, immutable';
export const PUBLIC_CACHE = 'public, max-age=31536000, immutable';

const VARS = ['R2_ACCOUNT_ID', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY', 'R2_BUCKET'];
/** An S3 "not there" answer: a head's NotFound, a get's or a copy's NoSuchKey, or a plain 404. */
const missing = (err) => err?.name === 'NotFound' || err?.name === 'NoSuchKey' || err?.$metadata?.httpStatusCode === 404;
/** A key as a copy's source names it: URL-encoded, its slashes kept. */
const sourceOf = (bucket, key) => `${bucket}/${encodeURIComponent(key).replace(/%2F/g, '/')}`;

/** Whether the variables are all there (and R2_PUBLIC_URL, for a public bucket). */
export const r2Configured = (env = process.env, { isPublic = false } = {}) =>
  VARS.every((v) => env[v]) && (!isPublic || Boolean(env.R2_PUBLIC_URL));

/**
 * The bucket, or null when it is not configured. `isPublic` marks objects public and gives
 * publicUrl(key); `client` stands a fake S3 client ({ send(command, options) }) in for tests;
 * `timeoutMs` shortens the wait.
 */
export function createR2Store(env = process.env, { isPublic = false, client, timeoutMs = R2_TIMEOUT_MS, cacheControl } = {}) {
  if (!r2Configured(env, { isPublic })) return null;
  const Bucket = env.R2_BUCKET;
  const s3 = client ?? new S3Client({
    region: 'auto',
    endpoint: `https://${env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: { accessKeyId: env.R2_ACCESS_KEY_ID, secretAccessKey: env.R2_SECRET_ACCESS_KEY },
  });
  const send = (command) => s3.send(command, { abortSignal: AbortSignal.timeout(timeoutMs) });
  const CacheControl = cacheControl ?? (isPublic ? PUBLIC_CACHE : PRIVATE_CACHE);
  const base = isPublic ? String(env.R2_PUBLIC_URL).replace(/\/+$/, '') : null;
  /** What is under a key: { contentType, length, cacheControl }, or null when nothing is. */
  async function head(key) {
    try {
      const res = await send(new HeadObjectCommand({ Bucket, Key: key }));
      return { contentType: res.ContentType ?? 'application/octet-stream', length: res.ContentLength, cacheControl: res.CacheControl ?? null };
    } catch (err) {
      if (missing(err)) return null;
      throw err;
    }
  }
  return {
    bucket: Bucket,
    put: (key, body, contentType) => send(new PutObjectCommand({ Bucket, Key: key, Body: body, ContentType: contentType, CacheControl })),
    async get(key) {
      const res = await send(new GetObjectCommand({ Bucket, Key: key }));
      return { body: res.Body, contentType: res.ContentType ?? 'application/octet-stream', length: res.ContentLength };
    },
    head,
    /** Copies an object to a new key inside the bucket (a clone taking its own copy of a file). The
     *  copy is cached like a put (an object put before that header existed has none, and a plain
     *  copy would carry that over), under the source's type unless `contentType` names one; a
     *  missing source is a NoSuchKey error, as a get's is. */
    async copy(fromKey, toKey, { contentType } = {}) {
      const ContentType = contentType ?? (await head(fromKey))?.contentType;
      if (!ContentType) throw Object.assign(new Error(`No object at ${fromKey}`), { name: 'NoSuchKey', $metadata: { httpStatusCode: 404 } });
      return send(new CopyObjectCommand({ Bucket, Key: toKey, CopySource: sourceOf(Bucket, fromKey), MetadataDirective: 'REPLACE', ContentType, CacheControl }));
    },
    // deleting a key that is not there is not an error
    del: (key) => send(new DeleteObjectCommand({ Bucket, Key: key })),
    /** Deletes every object under a prefix (all of one world's files), a page of up to 1000 at a
     *  time, and answers how many went. A key the bucket would not delete is an error naming it.
     *  An empty prefix is refused: it would be the whole bucket. */
    async deletePrefix(prefix) {
      if (typeof prefix !== 'string' || !prefix.replace(/\/+$/, '')) throw new Error('deletePrefix needs a prefix: an empty one would be the whole bucket');
      let removed = 0;
      let ContinuationToken;
      do {
        const page = await send(new ListObjectsV2Command({ Bucket, Prefix: prefix, ContinuationToken }));
        const Objects = (page.Contents ?? []).map((o) => ({ Key: o.Key }));
        if (Objects.length) {
          const res = await send(new DeleteObjectsCommand({ Bucket, Delete: { Objects, Quiet: true } }));
          if (res.Errors?.length) {
            const [first] = res.Errors;
            throw new Error(`R2 did not delete ${res.Errors.length} object(s) under ${prefix} (${first.Key}: ${first.Code ?? first.Message ?? 'refused'})`);
          }
          removed += Objects.length;
        }
        ContinuationToken = page.IsTruncated ? page.NextContinuationToken : undefined;
      } while (ContinuationToken);
      return removed;
    },
    /** Up to `max` keys under a prefix (a sweep's listing). */
    async list(prefix, { max = 1000 } = {}) {
      const keys = [];
      let ContinuationToken;
      do {
        const res = await send(new ListObjectsV2Command({ Bucket, Prefix: prefix, ContinuationToken, MaxKeys: Math.min(1000, max - keys.length) }));
        for (const o of res.Contents ?? []) keys.push(o.Key);
        ContinuationToken = res.IsTruncated ? res.NextContinuationToken : undefined;
      } while (ContinuationToken && keys.length < max);
      return keys;
    },
    publicUrl: (key) => (base ? `${base}/${key}` : null),
  };
}

/** What the bytes are, by their magic numbers, never by a file name or what the browser says.
 *  Images a browser draws everywhere: never GIF, never SVG (it can carry script). */
export function sniffImage(buf) {
  if (!buf || buf.length < 3) return null;
  if (buf.length >= 12 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return { ext: 'webp', type: 'image/webp' };
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { ext: 'jpg', type: 'image/jpeg' };
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { ext: 'png', type: 'image/png' };
  return null;
}

/** sniffImage, plus a PDF and a phone's HEIC photo: for documents people upload as proof. */
export function sniffDocument(buf) {
  const image = sniffImage(buf);
  if (image) return image;
  if (!buf || buf.length < 12) return null;
  if (buf.toString('latin1', 0, 4) === '%PDF') return { ext: 'pdf', type: 'application/pdf' };
  if (buf.toString('latin1', 4, 8) === 'ftyp' && ['heic', 'heix', 'heim', 'heis', 'mif1', 'msf1'].includes(buf.toString('latin1', 8, 12))) return { ext: 'heic', type: 'image/heic' };
  return null;
}

/** A new, never-reused key: `<prefix>/<24 hex>.<ext>`. */
export const newKey = (prefix, ext) => `${String(prefix).replace(/\/+$/, '')}/${crypto.randomBytes(12).toString('hex')}.${ext}`;

/** Streams an object to the browser, after the app's own checks. The body is destroyed when the
 *  browser goes away, so a stalled download does not keep the connection to R2. A missing key is
 *  a 404; a bucket that fails is a 502. */
export async function sendObject(res, store, key, { cacheControl = PRIVATE_CACHE } = {}) {
  let obj;
  try {
    obj = await store.get(key);
  } catch (err) {
    if (err?.name === 'NoSuchKey' || err?.$metadata?.httpStatusCode === 404) return res.status(404).json({ error: 'Not found' });
    console.error('R2 read failed:', err?.name, err?.$metadata?.httpStatusCode ?? '', err?.message);
    return res.status(502).json({ error: 'Could not load that file. Try again.' });
  }
  res.set({ 'Content-Type': obj.contentType, 'Cache-Control': cacheControl, 'X-Content-Type-Options': 'nosniff' });
  if (obj.length != null) res.set('Content-Length', String(obj.length));
  res.on('close', () => obj.body?.destroy?.());
  obj.body.on?.('error', () => res.destroy());
  obj.body.pipe(res);
}

/**
 * Moves rows still holding their file in the database to the bucket, one row at a time, and only
 * with `apply` (otherwise it lists what it would move). `rows()` lists the candidates; `read(row)`
 * gives { data: Buffer, type, ext } or null (left in place); `keyFor(row, ext)` names the object;
 * `save(row, key)` points the row at it and drops the inline copy, answering false when the row
 * changed meanwhile (the object is then deleted again). Idempotent. Returns { found, moved, failed }.
 */
export async function moveToR2({ store, rows, read, keyFor, save, apply = false, log = console.log }) {
  if (apply && !store) throw new Error('R2 is not configured');
  const list = await rows();
  const out = { found: list.length, moved: 0, failed: 0 };
  log(`${list.length} row(s) to move${apply ? '' : ' (dry run: nothing is written)'}`);
  if (!apply) return out;
  for (const row of list) {
    let key = null;
    try {
      const file = await read(row);
      if (!file) {
        out.failed++;
        log(`  x ${row.id}: not a file the bucket takes, left in the database`);
        continue;
      }
      key = keyFor(row, file.ext);
      await store.put(key, file.data, file.type);
      if (!(await save(row, key))) {
        await store.del(key); // the row changed under us: keep it as it was
        key = null;
        continue;
      }
      out.moved++;
      log(`  ok ${row.id} -> ${key}`);
    } catch (err) {
      out.failed++;
      log(`  x ${row.id}: ${err?.message ?? err}`);
      if (key) await store.del(key).catch(() => {}); // the put may have landed before the failure
    }
  }
  log(`Moved ${out.moved}, failed ${out.failed}.`);
  return out;
}
