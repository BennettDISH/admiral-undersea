// GET /health, the platform's deploy healthcheck: the process is up and serving, and with a
// database, one SELECT 1 comes back within timeoutMs. Nothing else is read, so it stays cheap
// however often it is asked. 200 { status: 'ok', db } or 503 { status: 'unavailable',
// db: 'not answering' }, never the database's own words (they can name hosts and users), and
// never kept by a cache. Without a database: 200 { status: 'ok', db: 'off' }.
import { wrap } from './errors.js';

export const HEALTH_TIMEOUT_MS = 2000;

/**
 * `db`: a pg Pool (or anything with query(sql)), a node:sqlite / better-sqlite3 database
 * (prepare(sql).get()), or null for none. Or `query(sql)` directly, with `enabled` (a boolean or
 * a function) saying whether there is a database at all. `info()` adds fields (a short commit;
 * nothing secret).
 */
export function health({ db, query, enabled = true, timeoutMs = HEALTH_TIMEOUT_MS, info } = {}) {
  let ask = query;
  if (!ask && db) {
    if (typeof db.query === 'function') ask = (sql) => db.query(sql);
    else if (typeof db.prepare === 'function') ask = (sql) => db.prepare(sql).get();
    else throw new Error('health: db has neither query() nor prepare()');
  }
  const on = () => Boolean(ask) && (typeof enabled === 'function' ? enabled() : enabled);
  return wrap(async (_req, res) => {
    res.set('Cache-Control', 'no-store');
    const extra = info ? info() : {};
    if (!on()) return res.json({ status: 'ok', db: 'off', ...extra });
    let timer;
    const asked = Promise.resolve().then(() => ask('SELECT 1'));
    asked.catch(() => {}); // a late failure after the timeout must not become an unhandled rejection
    const late = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('timeout')), timeoutMs);
    });
    try {
      await Promise.race([asked, late]);
      res.json({ status: 'ok', db: 'ok', ...extra });
    } catch {
      res.status(503).json({ status: 'unavailable', db: 'not answering', ...extra });
    } finally {
      clearTimeout(timer);
    }
  });
}

/** The commit the platform built, short, for info(): which build is running. */
export const buildInfo = (env = process.env) => ({ commit: String(env.RAILWAY_GIT_COMMIT_SHA || '').slice(0, 7) || null });
