export declare function sameOriginWrites(opts?: { message?: string; except?: string[] }): (req: any, res: any, next: (err?: unknown) => void) => unknown;
export declare function originAllowed(
  req: { headers: Record<string, string | string[] | undefined> },
  opts?: { baseUrl?: string; env?: Record<string, string | undefined> }
): boolean;
