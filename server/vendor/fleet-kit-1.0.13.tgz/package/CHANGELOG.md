# Changelog

- v1.0.13: who sent a bug report. `wp.router` answers `GET /bug-reporter` with a five-minute
  token naming this app (`aud: '<app>:bug-report'`) and the signed-in person's Waypoint id and
  display name, plus a random `jti` so each token is its own, for the bug widget to send with a
  report; signed out, a guest, or any page but the app's own (`Sec-Fetch-Site` other than
  same-origin) gets `{ token: null }`. The tracker asks `POST /bug-reporter/verify` server to
  server who a token names: only this app's own unaltered, unexpired reporter token answers
  `{ user: { id, name } }`, everything else `{ user: null }`; a browser on another site is
  refused, and the check is limited per address (`limits.reporter`). `reporterName(user)` names
  the person for an app whose rows keep the name elsewhere; `bugReporter: false` takes both
  routes away. Nothing else changes; the routes sit under `/api/auth/*`, so a security test
  that names its auth routes one by one has two more.
- v1.0.12: Create an account. `/sso/login?prompt=create` passes `prompt=create` to Waypoint, which
  opens its sign-up form and comes back signed in through the usual callback (Waypoint 5422c20 or
  later); only `login` and `create`, spelled exactly, go through. An app with `guests: 'refuse'`
  adds `guests=refuse` to every authorize address, so Waypoint's page offers no guest start (it
  needs Waypoint's tmwbc40rj change to matter, and is harmless before). The top bar shows "Create
  account" next to "Sign in" when signed out (`signup="off"` to leave it out; event
  `fleet-topbar-signup`), and `signUpUrl(auth, { next })` builds the link for an app's own page.
  An app that compares Waypoint's authorize address in its tests sees the new `guests` key.
- v1.0.11: test set only, nothing an app runs changes. A write's redirect counts as a refusal only
  if it goes to sign-in (`signIn` names the address, for an app whose sign-in isn't called that), so
  an admin tool that redirects after its work can't lose its gate and pass. A read's redirect still
  counts: nothing was served. An app may have to name its address at this bump.
- v1.0.10: `wp.requireAdmin` answers `Cache-Control: no-store`, as the plain `requireAdmin` and
  `requireUser` have since 1.0.8. A route that wants caching still sets its own after it.
- v1.0.9: test set only, nothing an app runs changes. A page in `adminPages` must get the gate's
  own redirect or 403 in every spelling: in a page app the shell looks the same with the gate gone,
  so it no longer counts as a refusal there. A bare `/*` on a list names Express 4's catch-all route
  and nothing else, where it used to make every route match. `tricks` takes the spellings to try,
  for an app big enough that all of them would outrun its test time.
- v1.0.8 (security): what kept being found app by app now has one home. `pathMatcher(pattern)`
  tests a path in any case and every spelling, for a gate of an app's own (`adminPage` uses it).
  `isPushEndpoint` and `validPushKeys` are the push checks four apps had copied, with the host
  labels tightened so an empty one is refused. `requireUser` and `requireAdmin` answer
  `Cache-Control: no-store`, and `noStore()` does the same for an app that checks `req.user`
  itself; a route that wants caching still sets its own after them. `createWaypoint({ register:
  false })` keeps password sign-in with no sign-up, in every spelling, where a route in front of
  the mount could be walked past by `/api/auth//register`.
  `fleet-kit/test/security` is a test set each app runs on its own routes: `securityChecks` walks
  the app's route table, so a new route has to be public, guarded or named, and tries each one
  under path tricks, as another account, as a guest and from another site, with bad push addresses
  and for answers a browser would keep. It needs no database or runner of its own.
- v1.0.7 (security): session tokens name their app (`aud`, the app code), and an app refuses another
  app's, under its own cookie or through a legacy reader. A token with no `aud` still counts if it
  was minted before 2026-12-01 (`UNBOUND_BEFORE`), until its own exp, so nobody is signed out by
  the bump; /me swaps it for one that names the app. Every app must be deployed on 1.0.7 before
  that date: one that deploys later signs out the sessions it minted after it. `aud` is the kit's
  own claim, and an app's `claims` may not set it. A test that signs a kit token by hand needs
  `aud` too, or it starts failing on that date.
  The kit's async middleware (`loadUser`, `requireUser`, `requireAdmin`, `adminPage`, `health`)
  passes a rejection to next(err); under Express 4 it was an unhandled rejection, which exits Node.
  `createWaypoint` refuses a write from another site on all its own routes (`/logout`, `/guest`,
  `/login`, `/register`, `/claim`), whether or not the app added `sameOriginWrites`.
  `adminPage` asks `pages` about every spelling of the path, in any case: %xx decoded, // collapsed,
  /x/../ resolved, a backslash as a slash, with or without a trailing slash (`pathSpellings`, also
  exported). README: install from the vendored tarball, sign-out everywhere needs `load`.
- v1.0.6: the R2 store heads an object (`head(key)`: type, length and caching, or null), copies one
  inside the bucket (`copy(from, to, { contentType })`, cached like a put, under the source's type
  unless one is named) and deletes everything under a prefix (`deletePrefix(prefix)`, a batch per
  page of 1000, answering how many; an empty prefix and a key the bucket refuses are errors), each
  call with the 15 s limit. The fake bucket answers those commands and pages its listings.
- v1.0.5: errorHandler answers a 4xx marked expose: false (res.sendFile's missing file is a 404)
  with its own status and the standard phrase, unlogged, instead of a logged 500.
  securityHeaders({ nonce: true }) gives every response a fresh nonce in res.locals.cspNonce and
  in script-src, for a page's own inline scripts; buildCsp({ nonce: true }) puts the NONCE
  placeholder in a prebuilt policy.
- v1.0.4: an app's own refusal from onSignIn (an HttpError, or any error with a 4xx status and
  expose not false) keeps its words: /login, /register and /guest answer its status and message,
  and the callback redirects to signInPage?error=<err.code or sso_refused>&message=<it>; nothing is
  saved or logged, and a refused guest gives its slot back. The no-guest refusal page's "Back"
  link goes to signInPage?error=sso_guest instead of /.
- v1.0.3: /claim also refuses an answer without its recovery code (502, nothing saved); /register
  passes a sign-up form's first and last names on to Waypoint; requestLog looks console.log up per
  line (a test can capture it) and takes `tokens: ['/p/:token', …]` to hide an app's shorter share
  tokens, in error lines too; the fake Waypoint keeps names on register.
- v1.0.2 (security): /claim refuses Waypoint's answer when it names a central id other than the
  guest's own: no row, no session and no recovery code for it (502); a claim hook that returns
  another id mints no session either. The test fake Waypoint can answer a route its own way
  (`wp.answer(path, fn)`).
- v1.0.1: publicUser(user, req) may be async (an answer that needs the database), and is awaited
  in /me and every sign-in answer; an optional isAdmin(user, { listed }) hook (createWaypoint or
  createSession, sync or async) gives an app admins of its own; never a guest, and a hook that
  throws or answers anything but true is a no.
- v1.0.0: first release. Waypoint sign-in, the cookie session (with legacy readers), admin gate,
  health, security headers, same-origin guard, limits, request log, errors, R2, migrations, guest
  check and sweep, WebSocket limits, the `<fleet-topbar>` component, and the test fakes; ESM and
  CommonJS builds.
