# Changelog

- v1.0.0: first release. Waypoint sign-in, the cookie session (with legacy readers), admin gate,
  health, security headers, same-origin guard, limits, request log, errors, R2, migrations, guest
  check and sweep, WebSocket limits, the `<fleet-topbar>` component, and the test fakes; ESM and
  CommonJS builds.
