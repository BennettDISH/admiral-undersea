// A fake S3 client ({ send(command) }) holding R2's objects in memory, so the real store
// (fleet-kit/server/r2) builds the same commands and headers it sends to R2. Set `down.put`,
// `down.get`, `down.del` or `down.list` to make that call fail. With `hold.get` a read answers
// the first bytes and then keeps its body open (listed in `held`), like a stalled connection.
import crypto from 'node:crypto';
import { Readable } from 'node:stream';

export function fakeS3() {
  const objects = new Map(); // key -> { bucket, contentType, cacheControl, body: Buffer }
  const down = { put: false, get: false, del: false, list: false };
  const hold = { get: false };
  const held = [];
  const calls = [];
  const fail = () => Object.assign(new Error('fake R2 is down'), { name: 'ServiceUnavailable', $metadata: { httpStatusCode: 503 } });
  return {
    objects,
    down,
    hold,
    held,
    calls,
    keys: () => [...objects.keys()].sort(),
    async send(command, options) {
      const { Bucket, Key, Body, ContentType, CacheControl, Prefix } = command.input;
      calls.push({ command: command.constructor.name, key: Key, signal: options?.abortSignal ?? null });
      switch (command.constructor.name) {
        case 'PutObjectCommand':
          if (down.put) throw fail();
          objects.set(Key, { bucket: Bucket, contentType: ContentType, cacheControl: CacheControl, body: Buffer.from(Body) });
          return {};
        case 'GetObjectCommand': {
          if (down.get) throw fail();
          const o = objects.get(Key);
          if (!o) throw Object.assign(new Error('The specified key does not exist.'), { name: 'NoSuchKey', $metadata: { httpStatusCode: 404 } });
          if (hold.get) {
            const body = new Readable({ read() {} });
            body.push(o.body.subarray(0, 8));
            held.push(body);
            return { Body: body, ContentType: o.contentType, ContentLength: o.body.length };
          }
          return { Body: Readable.from([o.body]), ContentType: o.contentType, ContentLength: o.body.length };
        }
        case 'DeleteObjectCommand':
          if (down.del) throw fail();
          objects.delete(Key);
          return {};
        case 'ListObjectsV2Command': {
          if (down.list) throw fail();
          const all = [...objects.keys()].filter((k) => k.startsWith(Prefix ?? '')).sort();
          return { Contents: all.map((k) => ({ Key: k })), IsTruncated: false };
        }
        default:
          throw new Error(`fake R2 does not know ${command.constructor.name}`);
      }
    },
  };
}

export const FAKE_BUCKET = 'fleet-kit-test';
/** Env for createR2Store: fake values only. */
export const R2_ENV = { R2_ACCOUNT_ID: 'test-account', R2_ACCESS_KEY_ID: 'test-key', R2_SECRET_ACCESS_KEY: 'test-secret-key', R2_BUCKET: FAKE_BUCKET };
export const R2_PUBLIC_ENV = { ...R2_ENV, R2_PUBLIC_URL: 'https://media.example.test' };

/** The real store over a fake bucket: { s3, store }. Pass createR2Store (from fleet-kit/server/r2). */
export function fakeStore(createR2Store, { isPublic = false, timeoutMs } = {}) {
  const s3 = fakeS3();
  return { s3, store: createR2Store(isPublic ? R2_PUBLIC_ENV : R2_ENV, { client: s3, isPublic, ...(timeoutMs ? { timeoutMs } : {}) }) };
}

/** Not decodable pictures, just the bytes a sniffer looks at: the magic number, then filler. */
export const webp = (size = 64) => Buffer.concat([Buffer.from('RIFF'), Buffer.alloc(4), Buffer.from('WEBPVP8 '), crypto.randomBytes(size)]);
export const jpeg = (size = 64) => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), crypto.randomBytes(size)]);
export const png = (size = 64) => Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), crypto.randomBytes(size)]);
export const pdf = (size = 64) => Buffer.concat([Buffer.from('%PDF-1.7\n'), crypto.randomBytes(size)]);
