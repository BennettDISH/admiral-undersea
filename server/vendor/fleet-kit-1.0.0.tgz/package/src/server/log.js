// One line per request with an id to find it again, and nothing secret: no query strings
// (Waypoint's ?code=&state= land on the callback URL), no bodies, headers or cookies, and
// path segments that look like tokens (invite and share links) logged as :token.
import crypto from 'node:crypto';

const ID_RE = /^[A-Za-z0-9._-]{8,64}$/;
export const scrubPath = (p) => p.split('/').map((s) => (/^[A-Za-z0-9_-]{16,}$/.test(s) ? ':token' : s)).join('/');

/** The request's path for a log line: originalUrl (req.path loses the mount under
 *  app.use('/api', ...)), cut at the query, tokens scrubbed. */
export const loggedPath = (req) => scrubPath(String(req.originalUrl ?? req.url ?? '').split('?')[0]);

export function requestLog({ skip = (req) => req.path === '/health' || req.path === '/healthz', log = console.log } = {}) {
  return (req, res, next) => {
    const given = req.get('x-request-id');
    req.id = given && ID_RE.test(given) ? given : crypto.randomUUID();
    res.set('X-Request-Id', req.id);
    if (skip(req)) return next();
    const logged = loggedPath(req);
    const started = process.hrtime.bigint();
    res.on('finish', () => {
      const ms = Number(process.hrtime.bigint() - started) / 1e6;
      log(`${req.id} ${req.method} ${logged} ${res.statusCode} ${Math.round(ms)}ms`);
    });
    next();
  };
}

/** An error's log line: the request's id, method and scrubbed path, then the error. Never the
 *  body, query, headers, cookies, tokens or Waypoint's answers. */
export function logError(req, err, log = console.error) {
  log(req?.id, req?.method, req ? loggedPath(req) : '', err);
}
