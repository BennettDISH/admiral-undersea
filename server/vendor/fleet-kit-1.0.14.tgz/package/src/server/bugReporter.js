// Who sent a bug report. The bug widget runs on an app's pages and asks GET /bug-reporter, on
// that address (under /api/auth), for a token naming whoever is signed in there; it sends that
// token with the report. The tracker takes no name or id from a browser: it posts the token to
// /bug-reporter/verify at the address it has for the app, and files the report under the answer.
// The token is signed with the session secret for `<app>:bug-report` (a session names `<app>`, so
// neither passes for the other, and a sibling app sharing the secret names its own code), lasts
// five minutes, and holds the Waypoint id and name (and a random jti), nothing else. Someone
// signed out, a guest, or a request from any other site's page gets no token: an anonymous report.
//
// createWaypoint puts both routes in wp.router. An app whose sign-in is its own mounts them where
// the widget asks:
//
//   app.use('/api/auth', bugReporter({ app: 'cp', secret: () => process.env.SESSION_SECRET, user: (req) => resolveUser(req) }));
import crypto from 'node:crypto';
import express from 'express';
import { wrap } from './errors.js';
import { rateLimit } from './limits.js';
import { sameOriginWrites } from './sameOrigin.js';
import { signJwt, verifyJwt } from './jwt.js';

const MINUTE = 60 * 1000;
/** How long a bug reporter's token lasts: the widget asks for one as the report is sent. */
export const REPORTER_TTL_MS = 5 * MINUTE;
const REPORTER_TOKEN_MAX = 2048;

/** A name as a report keeps it: one line, at most 100 characters; null for anything else. */
const oneLine = (value) => {
  if (typeof value !== 'string') return null;
  const line = value.replace(/[\u0000-\u001f\u007f]+/g, ' ').trim().slice(0, 100);
  return line || null;
};

/** The name a bug report is filed under: the account's display name, else its username, else
 *  its name, one line, at most 100 characters; null when it has none. An app whose rows keep the
 *  name elsewhere passes `reporterName(user)` to createWaypoint (or bugReporter). */
export function reporterName(user) {
  return oneLine([user?.display_name, user?.username, user?.name].find((v) => typeof v === 'string' && v.trim()));
}

/** The reporter limit's defaults: 120 checks per address per 15 minutes. */
export const reporterLimit = (overrides = {}) => rateLimit({ windowMs: 15 * MINUTE, max: 120, message: 'Too many checks from here. Try again later.', ...overrides });

/**
 * Adds GET /bug-reporter and POST /bug-reporter/verify to `router`, which refuses another site's
 * writes already (sameOriginWrites). `secret()` is the session secret; `user(req, res)` answers
 * the signed-in account (with `central_user_id`, the Waypoint id, and `is_guest`) or null.
 */
export function addReporterRoutes(router, { app, secret, user, reporterName: nameOf = reporterName, limit = reporterLimit() }) {
  if (!app || typeof app !== 'string') throw new Error('the bug reporter needs the app code');
  if (typeof secret !== 'function') throw new Error('the bug reporter needs secret: () => the session secret');
  if (typeof user !== 'function') throw new Error('the bug reporter needs user(req, res) => the signed-in account or null');
  if (typeof nameOf !== 'function') throw new Error('reporterName must be a function (user) => the name a bug report is filed under');
  const aud = `${app}:bug-report`;
  const json = express.json({ limit: '16kb' });

  router.get('/bug-reporter', wrap(async (req, res) => {
    res.set('Cache-Control', 'no-store');
    const none = () => res.json({ token: null });
    // the page's own fetch says same-origin; a sibling under the same front door (same-site)
    // or anyone else gets nothing, even though the answer would be unreadable to them
    const from = req.get('sec-fetch-site');
    if (from && from !== 'same-origin') return none();
    const key = secret();
    if (!key) return none();
    const who = await user(req, res);
    const cid = Number(who?.central_user_id);
    if (!who || who.is_guest || !Number.isSafeInteger(cid) || cid <= 0) return none();
    // jti: two reports in the same second still carry two tokens, so the tracker can take each once
    const jti = crypto.randomBytes(12).toString('base64url');
    let name = null;
    try {
      name = oneLine(await nameOf(who));
    } catch {
      name = null; // the app's hook failed: the report still says which account
    }
    res.json({ token: signJwt({ aud, cid, name, jti }, key, { ttlMs: REPORTER_TTL_MS }) });
  }));

  // The tracker's question, server to server: who does this token name? Only a token this app
  // minted for bug reports, unaltered and within its five minutes, has an answer; anything else
  // is { user: null }. The token is in the body, never the address, so no log sees it.
  router.post('/bug-reporter/verify', limit, json, (req, res) => {
    res.set('Cache-Control', 'no-store');
    const token = req.body?.token;
    const key = secret();
    const claims = key && typeof token === 'string' && token.length <= REPORTER_TOKEN_MAX ? verifyJwt(token, key) : null;
    const cid = Number(claims?.cid);
    const fresh = typeof claims?.exp === 'number' && claims.exp * 1000 <= Date.now() + REPORTER_TTL_MS;
    if (!claims || claims.aud !== aud || !fresh || !Number.isSafeInteger(cid) || cid <= 0) return res.json({ user: null });
    res.json({ user: { id: cid, name: typeof claims.name === 'string' ? claims.name.slice(0, 100) : null } });
  });
  return router;
}

/**
 * The two routes on a router of their own, for an app whose sign-in isn't createWaypoint's: mount
 * it at /api/auth, where the widget asks. `user(req, res)` answers the signed-in account (with
 * `central_user_id` and `is_guest`) or null, and is the only thing that decides who is named.
 * `limits.reporter` changes the verify limit, as in createWaypoint.
 */
export function bugReporter({ app, secret, user, reporterName: nameOf = reporterName, limits = {} } = {}) {
  const router = express.Router();
  router.use(sameOriginWrites());
  return addReporterRoutes(router, {
    app,
    secret: typeof secret === 'function' ? secret : () => secret,
    user,
    reporterName: nameOf,
    limit: reporterLimit(limits.reporter || {}),
  });
}
