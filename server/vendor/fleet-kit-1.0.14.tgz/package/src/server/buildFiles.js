// A built page app (Vite's dist/), served the one way every app should. Mount it after the API,
// in place of express.static, assetNotFound and spaFallback:
//
//   app.use('/api', apiNotFound());
//   app.use(buildFiles(path.join(__dirname, 'dist')));
//   app.use(errorHandler());
//
// - /assets/* (Vite's content-hashed names) is kept for a year and never asked about again
//   (immutable): a new build is a new name, so a returning visitor loads nothing twice.
// - The page (index.html, and any other .html in the build) is never kept (no-store): a tab
//   coming back after a deploy must not show the old page, naming bundles that are gone.
// - Any other file in the build (a favicon, the manifest, a service worker, public/ files with
//   fixed names) is asked about on every load (no-cache, answered 304 while unchanged), so a
//   change reaches the next visit. `cacheFor(path)` may say otherwise for one of those.
// - A missing /assets file is a plain 404: a tab older than the last deploy asking for a bundle
//   that is gone must not get the page back, which the browser would try to run.
// - Every other GET or HEAD gets the page (the client's own routes), except /api (`skip`), which
//   is left to the app's apiNotFound. `fallback: false` leaves unknown paths to the app instead.
//
// A path is read decoded, slashes run together, and the assets folder in any case. '..', '.'
// and dotfiles, a backslash or a NUL never reach a file: in /assets that is a 404, elsewhere the
// page. Five apps were found on 11-15 sending their hashed bundles with max-age=0, each having
// wired this by hand; the security set's `build` check holds every app to it.
import fs from 'node:fs';
import path from 'node:path';

/** Cache-Control for a content-hashed file: a year, and never revalidated. */
export const YEAR_IMMUTABLE = 'public, max-age=31536000, immutable';
export const BUILD_FILES = Symbol.for('fleet-kit.build-files');

/** The path's parts once decoded, or null when it is not one a file may be read by. */
function partsOf(raw) {
  let decoded;
  try {
    decoded = decodeURIComponent(raw);
  } catch {
    return null;
  }
  if (decoded.includes('\0') || decoded.includes('\\')) return null;
  const parts = decoded.split('/').filter(Boolean);
  return parts.some((p) => p.startsWith('.')) ? null : parts;
}

const statFile = (file) => new Promise((resolve) => {
  fs.stat(file, (err, st) => resolve(!err && st.isFile()));
});

/**
 * Middleware serving the build in `dist`. Options:
 *   page      the page's file in dist (index.html), or (req, res, next) => sends the page, for an
 *             app that fills it in per request; it is sent no-store either way
 *   assets    the hashed folder's name in dist (assets)
 *   skip      path prefixes left to the app, in any case (['/api'])
 *   fallback  false: an unknown path goes on to the app instead of getting the page
 *   cacheFor  (path) => a Cache-Control for one of the other files (path is '/widget.js'), or
 *             undefined for no-cache
 */
export function buildFiles(dist, { page = 'index.html', assets = 'assets', skip = ['/api'], fallback = true, cacheFor } = {}) {
  if (typeof dist !== 'string' || !dist) throw new Error('buildFiles needs the build folder');
  if (typeof page !== 'string' && typeof page !== 'function') throw new Error('page is a file name in the build or (req, res, next) => sends the page');
  const root = path.resolve(dist);
  const pageName = typeof page === 'string' ? page.replace(/^\/+/, '') : null;
  // the built page's own address answers as the page, filled in or not
  const pageRel = pageName ?? 'index.html';
  const skipped = [].concat(skip ?? []).map((p) => `/${String(p).replace(/^\/+|\/+$/g, '')}`.toLowerCase());
  const assetsDir = String(assets).replace(/^\/+|\/+$/g, '');
  if (!assetsDir || assetsDir.split('/').some((p) => p.startsWith('.'))) throw new Error('assets is a folder in the build');
  const assetsPrefix = `/${assetsDir}`.toLowerCase();
  const assetsDepth = assetsDir.split('/').length;

  const send = (res, file, cacheControl) => {
    // the parts were checked above, so the folder holding dist may have a dot in its path
    res.sendFile(file, { dotfiles: 'allow', cacheControl: false, headers: { 'Cache-Control': cacheControl } });
  };

  async function sendPage(req, res, next) {
    res.set('Cache-Control', 'no-store');
    if (!pageName) return page(req, res, next);
    const file = path.join(root, pageName);
    if (!(await statFile(file))) return next();
    return send(res, file, 'no-store');
  }

  async function serve(req, res, next) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    const parts = partsOf(req.path);
    const at = (parts ? `/${parts.join('/')}` : req.path.replace(/\/{2,}/g, '/')).toLowerCase();
    if (skipped.some((p) => at === p || at.startsWith(`${p}/`))) return next();
    const inAssets = at === assetsPrefix || at.startsWith(`${assetsPrefix}/`);
    const missing = () => {
      if (inAssets) return res.status(404).end();
      return fallback ? sendPage(req, res, next) : next();
    };
    if (!parts) return missing();
    const rel = parts.join('/');
    if (!rel || rel === pageRel) return sendPage(req, res, next);
    // the folder in any case: /ASSETS/x.js is the hashed file too
    const file = inAssets ? path.join(root, assetsDir, ...parts.slice(assetsDepth)) : path.join(root, ...parts);
    if (!(await statFile(file))) return missing();
    if (inAssets) return send(res, file, YEAR_IMMUTABLE);
    if (/\.html?$/i.test(rel)) return send(res, file, 'no-store');
    return send(res, file, cacheFor?.(`/${rel}`) ?? 'no-cache');
  }

  // Express 4 doesn't look at a promise a middleware returns: a rejection goes to next(err) here
  const middleware = (req, res, next) => {
    serve(req, res, next).catch(next);
  };
  middleware[BUILD_FILES] = { dist: root, assets: assetsDir, page: pageRel };
  return middleware;
}
