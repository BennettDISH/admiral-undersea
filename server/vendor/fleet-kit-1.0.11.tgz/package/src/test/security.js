// The fleet's security checks, run by each app on its own routes, in its normal tests, so they run
// at every push. The routes come from the app itself: a new route that names no decision fails.
//
// Import this file before the app is built (Express 5 keeps no readable mount path, so mounts are
// noted as they go on), then:
//
//   import { securityChecks } from 'fleet-kit/test/security';
//   import { app } from '../server.js';
//   for (const check of securityChecks({ app, base, as, public: [...], ... })) test(check.name, check.run);
//
// A server.js that builds and listens for itself can stay as it is: set PORT=0, import it after
// this file, and appListening() answers its app and address.
//
// It works under node:test and vitest. `app` and `base` may be getters, for a server a before-hook
// starts. `as` holds a function per account that answers request headers (usually a cookie made
// with wp.session.mint). Patterns are 'GET /api/things/:id', '/api/things/*' (any method), matched
// against the route as written. Only the checks you give options for run.
import http from 'node:http';
import crypto from 'node:crypto';

const express = await import('express').then((m) => m.default ?? m).catch(() => null);

const MOUNT = Symbol.for('fleet-kit.mount');
const NOTED = Symbol.for('fleet-kit.mounts-noted');

/** Done on import for the app's own express; another copy can be named. */
export function noteMounts(lib = express) {
  // Express 4's Router is its own prototype object; Express 5's has a real one.
  const proto = lib?.Router?.prototype?.use ? lib.Router.prototype : lib?.Router;
  if (!proto?.use || proto[NOTED]) return;
  const use = proto.use;
  proto.use = function noted(...args) {
    const before = this.stack.length;
    const out = use.apply(this, args);
    const first = Array.isArray(args[0]) ? args[0][0] : args[0];
    const mount = typeof first === 'function' ? '/' : args[0];
    for (const layer of this.stack.slice(before)) layer[MOUNT] = mount;
    return out;
  };
  proto[NOTED] = true;
}
noteMounts();

let listened;
const listening = new Promise((resolve) => { listened = resolve; });
if (express?.application?.listen && !express.application[NOTED]) {
  const { listen } = express.application;
  express.application.listen = function noted(...args) {
    const server = listen.apply(this, args);
    server.once('listening', () => listened({ app: this, server, base: `http://127.0.0.1:${server.address().port}` }));
    return server;
  };
  express.application[NOTED] = true;
}

/** { app, server, base } of the first Express app to listen in this process. */
export function appListening({ timeoutMs = 30_000 } = {}) {
  return Promise.race([
    listening,
    new Promise((_, reject) => { setTimeout(() => reject(new Error('no Express app called listen')), timeoutMs).unref(); }),
  ]);
}

const WRITES = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);
const join = (a, b) => (`${a}/${b}`.replace(/\/+/g, '/').replace(/(.)\/$/, '$1'));

function mountsOf(layer) {
  if (layer[MOUNT] !== undefined) return [].concat(layer[MOUNT]);
  if (!layer.regexp) throw new Error('fleet-kit/test/security has to be imported before the app is built');
  if (layer.regexp.fast_slash) return ['/'];
  let i = 0; // Express 4 keeps the mount as a pattern (an app built before this file was imported)
  return layer.regexp.source.split(/\|(?=\^)/).map((one) => one
    .replace(/^\^/, '')
    .replace(/\\\/\?\(\?=\\\/\|\$\)$/, '')
    .replace(/\(\?:\(\[\^\\\/\]\+\?\)\)/g, () => `:${layer.keys[i++]?.name ?? 'p'}`)
    .replace(/\\(.)/g, '$1'));
}

/** Every route an Express 4 or 5 app (or Router) holds: { method, path }, ALL for app.all, and a
 *  RegExp route as its source with regexp: true, since it can't be walked. */
export function listRoutes(app) {
  let router = app;
  if (!app.stack) {
    if (typeof app.lazyrouter === 'function') app.lazyrouter();
    router = app._router ?? app.router;
  }
  const seen = new Map();
  const add = (method, path, regexp) => seen.set(`${method} ${path}`, { method, path, ...(regexp ? { regexp } : {}) });
  const walk = (stack, prefix) => {
    for (const layer of stack) {
      if (layer.route) {
        let methods = Object.keys(layer.route.methods).filter((m) => layer.route.methods[m]);
        if (methods.length > 10) methods = ['_all']; // Express 5's app.all sets each method by name
        for (const p of [].concat(layer.route.path)) {
          const regexp = p instanceof RegExp;
          for (const m of methods) add(m === '_all' ? 'ALL' : m.toUpperCase(), regexp ? `${prefix}${p}` : join(prefix, p), regexp);
        }
      } else if (layer.handle?.stack) {
        for (const mount of mountsOf(layer)) walk(layer.handle.stack, mount instanceof RegExp ? `${prefix}${mount}` : join(prefix, mount));
      }
    }
  };
  walk(router?.stack ?? [], '');
  return [...seen.values()];
}

const firstEncoded = (s) => `%${s.charCodeAt(0).toString(16).padStart(2, '0')}${s.slice(1)}`;
const capital = (s) => s[0].toUpperCase() + s.slice(1);

/** The ways a request can spell a path that some part of the stack reads as that path. */
export function pathTricks(path) {
  const parts = path.split('/').filter(Boolean);
  if (!parts.length) return [];
  const last = parts.at(-1);
  const head = parts.slice(0, -1).map((p) => `/${p}`).join('');
  const rest = parts.slice(1).map((p) => `/${p}`).join('');
  return [...new Set([
    path.toUpperCase(),
    `/${capital(parts[0])}${rest}`,
    `${head}/${last.toUpperCase()}`,
    `${path}/`,
    `/${path}`,
    `${head}//${last}`,
    `/.${path}`,
    `/x/..${path}`,
    `/x/%2e%2e${path}`,
    `${head}/./${last}`,
    `${head}/x/../${last}`,
    `/${firstEncoded(parts[0])}${rest}`,
    `${head}/${firstEncoded(last)}`,
    `/${firstEncoded(parts[0]).replace('%', '%25')}${rest}`,
    `/\\${parts[0]}${rest}`,
    ...(head ? [`${head}\\${last}`, `${head}%2f${last}`] : []),
  ])].filter((p) => p !== path);
}

let sent = 0;
const nextAddress = () => {
  sent += 1;
  return `10.${(sent >> 16) & 255}.${(sent >> 8) & 255}.${sent & 255}`;
};

/** One request with the path exactly as written (fetch tidies //, /../ and %2e away first), on a
 *  connection of its own, from an address of its own so a per-address limit stays out of it. */
export function send(base, path, { method = 'GET', headers = {}, body } = {}) {
  const { hostname, port } = new URL(typeof base === 'function' ? base() : base);
  const payload = body === undefined ? null : typeof body === 'string' ? body : JSON.stringify(body);
  const all = {
    'x-forwarded-for': nextAddress(),
    ...(payload !== null ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(payload) } : {}),
    ...headers,
  };
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname, port, path, method, headers: all, agent: false }, (res) => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { text += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: text, location: res.headers.location }));
    });
    req.on('error', reject);
    if (payload !== null) req.write(payload);
    req.end();
  });
}

/** Addresses that must never be taken: each has fooled a check, or would reach the wrong host. */
export const BAD_PUSH_ENDPOINTS = [
  'https://evil.example;.push.apple.com/x',
  'https://127.0.0.1;.push.apple.com/x',
  'https://169.254.169.254;.push.apple.com/latest',
  "https://evil.example'.push.apple.com/x",
  'https://evil.example".push.apple.com/x',
  'https://evil.example{.push.apple.com/x',
  'https://evil.example}.push.apple.com/x',
  'https://evil.example`.push.apple.com/x',
  'https://evil.example\\.push.apple.com/x',
  'https://fcm.googleapis.com\\@evil.example/x',
  'https://user:pw@fcm.googleapis.com/x',
  'https://evil.example:1@web.push.apple.com/x',
  'https://web.push.apple.com?x',
  'https://web.push.apple.com/a b',
  'https://fcm.googleapis.com:8443/x',
  'http://fcm.googleapis.com/x',
  'https://fcm.googleapis.com.evil.example/x',
  'https://push.apple.com.evil.example/x',
  'https://web.push.apple.com./x',
  'https://evil.example/x',
  'https://127.0.0.1/x',
  'nope',
  '',
  ['https://fcm.googleapis.com/x'],
  { href: 'https://fcm.googleapis.com/x' },
  null,
];
export const GOOD_PUSH_ENDPOINTS = [
  'https://web.push.apple.com/QGv1abc-_xyz',
  'https://fcm.googleapis.com/fcm/send/dAbc:APA91bH-x_y',
  'https://updates.push.services.mozilla.com/wpush/v2/gAAAAABc-d_e',
  'https://wns2-par02p.notify.windows.com/w/?token=abc%3d',
];

/** Keys a subscribe route will take, so that only the address is wrong. */
export function pushKeys() {
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  return { p256dh: ecdh.getPublicKey('base64url'), auth: crypto.randomBytes(16).toString('base64url') };
}

function matcher(pattern) {
  const spaced = /^([A-Z]+|\*) (.*)$/s.exec(pattern);
  const method = spaced ? spaced[1] : '*';
  const path = spaced ? spaced[2] : pattern;
  // A bare /* names Express 4's catch-all route and nothing else: as a wildcard it would make every
  // route match, which no list means.
  const re = path === '/*' ? /^\/\*$/ : new RegExp(`^${path.split('*').map((s) => s.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*')}$`);
  return (route) => (method === '*' || method === route.method || route.method === 'ALL') && re.test(route.path);
}
const anyOf = (patterns = []) => {
  const all = patterns.map(matcher);
  return (route) => all.some((m) => m(route));
};
const value = (v) => (typeof v === 'function' ? v() : v);
const appOf = (v) => (typeof v === 'function' && !v.use ? v() : v);

/** The route's address with its params filled in: `params[name]`, else 1. An optional part is
 *  left out, a wildcard is x. */
export function fillPath(path, params = {}) {
  return path
    .replace(/\{[^{}]*\}/g, '')
    .replace(/:([A-Za-z0-9_]+)(\([^)]*\))?\??/g, (_, name) => encodeURIComponent(value(params[name]) ?? 1))
    .replace(/\*[A-Za-z0-9_]*/g, 'x') || '/';
}
const paramsOf = (path) => [...path.matchAll(/:([A-Za-z0-9_]+)/g)].map((m) => m[1]);
const methodsOf = (route) => (route.method === 'ALL' ? ['GET', 'POST'] : [route.method]);
const bodyFor = (method) => (WRITES.has(method) ? {} : undefined);

const REFUSED = new Set([401, 403, 404, 405, 410]);
const SIGN_IN = /sign-?in|log-?in|sso|\/auth(?:\/|$)/i;
const unnonced = (s) => s.replace(/nonce="[^"]*"/g, '').replace(/nonce-[A-Za-z0-9+/=]+/g, '');

async function inTurn(list, each) {
  let next = 0;
  await Promise.all(Array.from({ length: 8 }, async () => {
    while (next < list.length) await each(list[next++]);
  }));
}

function report(name, problems) {
  if (problems.length) throw new Error(`${name}:\n  ${problems.slice(0, 60).join('\n  ')}${problems.length > 60 ? `\n  …and ${problems.length - 60} more` : ''}`);
}

/**
 * The checks, as [{ name, run }]. Each run throws with the list of what failed.
 *
 *   app, base          the Express app and where it listens
 *   shell              (r) => whether an answer is the page every address gets, when that page
 *                      isn't the same for every address (<head> filled in per path, say)
 *   tricks             (path) => the spellings to try, for an app so big that all of them would
 *                      outrun its test time: (p) => pathTricks(p).slice(0, 6)
 *   signIn             a RegExp for where this app sends a refused write, if its sign-in address
 *                      isn't one the kit would know by its name
 *   as                 { user, other, guest, admin }: () => headers; `other` is an account that
 *                      shares nothing with `user`
 *   public             routes that answer signed out on purpose. Every other route has to refuse
 *                      a stranger, in every spelling. An entry that matches no route fails.
 *   admin, adminPages  routes, and page addresses behind a server gate, that only the admin
 *                      reaches. A page in adminPages must get the gate's own redirect or 403, in
 *                      every spelling; an app with no server gate lists none.
 *   closed             'METHOD /path' that must not answer at all, in any spelling
 *   crossSite          { except }: every write refuses another site's page, except these
 *   noStore            { except }: no signed-in 2xx GET may be kept by a browser, except these
 *   owned              { params: { id: value or getter }, except }: `other` is refused every
 *                      route naming one of these, and `user` must reach the GETs (a wrong id
 *                      would pass otherwise). A route with a param not named here fails, until
 *                      it is named or excepted.
 *   guests             { refused }: routes a guest may not use
 *   push               { route, body: (endpoint) => json, count?: () => n, as? }
 *   headers            { path, csp }: the fleet's headers are on what this path answers
 */
export function securityChecks(o) {
  const tricksOf = o.tricks ?? pathTricks;
  // A redirect says nothing was served, but a write that did its work and went back to a page
  // redirects too, so a write's redirect only counts when it goes to sign-in.
  const refused = (r, method = 'GET') => {
    if (REFUSED.has(r.status)) return true;
    if (r.status < 300 || r.status >= 400) return false;
    return !WRITES.has(method) || (o.signIn ?? SIGN_IN).test(String(r.location ?? ''));
  };
  const baseOf = () => value(o.base);
  const routes = () => {
    const all = listRoutes(appOf(o.app));
    if (!all.length) throw new Error('no routes found: import fleet-kit/test/security before the app is built');
    return all;
  };
  const account = (name) => value(o.as?.[name]) ?? {};
  const ofAccount = (name) => {
    if (!o.as?.[name]) throw new Error(`this check needs as.${name}`);
    return account(name);
  };
  const params = (route) => Object.fromEntries(paramsOf(route.path).map((p) => [p, o.owned?.params?.[p]]));

  // What an unknown address answers, for the account asking: a page app's shell comes back 200 for
  // any path, and nothing of the guarded thing is in it.
  async function nothingHere(headers) {
    const answers = await Promise.all(['/fleet-kit-no-such-page', '/api/fleet-kit-no-such-route'].map((p) => send(baseOf(), p, { headers })));
    return new Set(answers.filter((r) => r.status < 300).map((r) => unnonced(r.body)));
  }
  const isShell = (r, known) => r.status < 300 && (known.has(unnonced(r.body)) || Boolean(o.shell?.(r)));
  const limited = (r, what) => {
    if (r.status === 429) throw new Error(`a limit answered 429 at ${what}, so this walk can't tell; raise the limit in this test`);
  };

  /** The route, and each spelling of it, refuses this account. `strict`: the page every address
   *  gets doesn't count as a refusal. */
  async function mustRefuse(problems, route, headers, label, pass = refused, strict = false) {
    const shell = await nothingHere(headers);
    await inTurn(methodsOf(route).flatMap((method) => {
      const path = fillPath(route.path, params(route));
      return [path, ...tricksOf(path)].map((p) => ({ method, p }));
    }), async ({ method, p }) => {
      const r = await send(baseOf(), p, { method, headers, body: bodyFor(method) });
      limited(r, `${method} ${p}`);
      if (pass(r, method) || (!strict && isShell(r, shell))) return;
      problems.push(`${label}: ${method} ${p} answered ${r.status} (route ${route.path})`);
    });
  }

  const checks = [];
  const add = (name, run) => checks.push({ name: `security: ${name}`, run: async () => { await run(); } });
  const stale = (problems, patterns, list, label) => {
    for (const pattern of patterns ?? []) {
      if (!list.some(matcher(pattern))) problems.push(`${label}: ${pattern} matches no route; take it off the list`);
    }
  };

  if (o.public) {
    add('a stranger is refused every route but the public ones, in every spelling', async () => {
      const all = routes();
      const problems = [];
      stale(problems, o.public, all, 'public');
      const isPublic = anyOf(o.public);
      for (const route of all.filter((r) => !isPublic(r))) {
        if (route.regexp) problems.push(`${route.method} ${route.path}: a RegExp route can't be walked; list it in public and test it by hand`);
        else await mustRefuse(problems, route, {}, 'signed out');
      }
      report('Routes that answer a stranger', problems);
    });
  }

  if (o.admin || o.adminPages) {
    add('only the admin reaches the admin routes, in every spelling', async () => {
      const all = routes();
      const problems = [];
      stale(problems, o.admin, all, 'admin');
      const isAdmin = anyOf(o.admin);
      const data = all.filter((r) => isAdmin(r) && !r.regexp);
      // A page gate has to answer for itself. In a page app the shell looks the same with the gate
      // gone, so only its own redirect or 403 counts.
      const pages = (o.adminPages ?? []).map((path) => ({ method: 'GET', path }));
      for (const [who, headers] of [...['user', 'guest'].filter((n) => o.as?.[n]).map((n) => [n, account(n)]), ['signed out', {}]]) {
        for (const route of data) await mustRefuse(problems, route, headers, who);
        for (const route of pages) await mustRefuse(problems, route, headers, who, refused, true);
      }
      report('Admin routes that answer someone else', problems);
    });
  }

  if (o.closed) {
    add('closed routes stay closed, in every spelling', async () => {
      const problems = [];
      const gone = (r) => r.status === 404 || r.status === 405;
      for (const entry of o.closed) {
        const [, method = 'POST', path] = /^(?:([A-Z]+) )?(.*)$/.exec(entry);
        for (const who of ['', ...(o.as?.user ? ['user'] : [])]) {
          await mustRefuse(problems, { method, path }, who ? account(who) : {}, who || 'signed out', gone);
        }
      }
      report('Closed routes that answer', problems);
    });
  }

  if (o.crossSite) {
    add('a write from another site is refused, in every spelling', async () => {
      const all = routes();
      const problems = [];
      stale(problems, o.crossSite.except, all, 'crossSite.except');
      const skip = anyOf(o.crossSite.except);
      const headers = o.as?.admin ? account('admin') : o.as?.user ? account('user') : {};
      const shell = await nothingHere(headers);
      for (const route of all.filter((r) => !r.regexp && !skip(r) && (r.method === 'ALL' || WRITES.has(r.method)))) {
        const method = route.method === 'ALL' ? 'POST' : route.method;
        const path = fillPath(route.path, params(route));
        await inTurn(['cross-site', 'same-site'], async (from) => {
          const r = await send(baseOf(), path, { method, headers: { ...headers, 'sec-fetch-site': from }, body: {} });
          limited(r, `${method} ${path}`);
          if (r.status !== 403) problems.push(`${from}: ${method} ${path} answered ${r.status}, not 403`);
        });
        await inTurn(tricksOf(path), async (p) => {
          const r = await send(baseOf(), p, { method, headers: { ...headers, 'sec-fetch-site': 'cross-site' }, body: {} });
          limited(r, `${method} ${p}`);
          if (!refused(r, method) && !isShell(r, shell)) problems.push(`cross-site: ${method} ${p} answered ${r.status}`);
        });
      }
      report('Writes another site can send', problems);
    });
  }

  if (o.noStore) {
    add('a signed-in answer is never kept by the browser', async () => {
      const all = routes();
      const problems = [];
      stale(problems, o.noStore.except, all, 'noStore.except');
      const skip = anyOf([...(o.noStore.except ?? []), ...(o.public ?? [])]);
      let judged = 0;
      for (const who of ['user', 'admin'].filter((n) => o.as?.[n])) {
        await inTurn(all.filter((r) => !r.regexp && !skip(r) && (r.method === 'GET' || r.method === 'ALL')), async (route) => {
          const r = await send(baseOf(), fillPath(route.path, params(route)), { headers: account(who) });
          limited(r, route.path);
          if (r.status < 200 || r.status >= 300) return;
          judged += 1;
          if (!/no-store/i.test(String(r.headers['cache-control'] ?? ''))) problems.push(`${who}: GET ${route.path} answered ${r.status} with Cache-Control: ${r.headers['cache-control'] ?? 'none'}`);
        });
      }
      if (!judged) problems.push('no signed-in GET answered 2xx, so this proved nothing');
      report('Private answers a browser may keep', problems);
    });
  }

  if (o.owned) {
    add("another account is refused anything named by someone else's id", async () => {
      const all = routes();
      const problems = [];
      const notProved = [];
      stale(problems, o.owned.except, all, 'owned.except');
      const skip = anyOf([...(o.owned.except ?? []), ...(o.public ?? []), ...(o.admin ?? [])]);
      const named = new Set(Object.keys(o.owned.params ?? {}));
      for (const route of all.filter((r) => !r.regexp && !skip(r) && paramsOf(r.path).length)) {
        const unknown = paramsOf(route.path).filter((p) => !named.has(p));
        if (unknown.length) {
          problems.push(`${route.method} ${route.path}: name :${unknown.join(', :')} in owned.params, or list the route in owned.except`);
          continue;
        }
        const path = fillPath(route.path, params(route));
        for (const method of methodsOf(route)) {
          if (method === 'GET') {
            const mine = await send(baseOf(), path, { headers: ofAccount('user') });
            limited(mine, path);
            // a 400 got past the id to the route's own check of what else it wants
            if ((mine.status < 200 || mine.status >= 300) && mine.status !== 400 && mine.status !== 422) problems.push(`GET ${path}: its owner got ${mine.status}, so this id proves nothing; fix the id or except the route`);
          }
          const r = await send(baseOf(), path, { method, headers: ofAccount('other'), body: bodyFor(method) });
          limited(r, path);
          if (r.status === 400 || r.status === 422) notProved.push(`${method} ${path}`);
          else if (!REFUSED.has(r.status)) problems.push(`${method} ${path} answered ${r.status} for another account`);
        }
      }
      if (notProved.length) console.error(`security: the body was refused before the owner was asked, so these aren't proved: ${notProved.join(', ')}`);
      report("Other people's things another account reached", problems);
    });
  }

  if (o.guests) {
    add('a guest is refused what guests may not use, in every spelling', async () => {
      const all = routes();
      const problems = [];
      stale(problems, o.guests.refused, all, 'guests.refused');
      const isRefused = anyOf(o.guests.refused);
      for (const route of all.filter((r) => !r.regexp && isRefused(r))) await mustRefuse(problems, route, ofAccount('guest'), 'guest');
      report('Routes a guest reached', problems);
    });
  }

  if (o.push) {
    add('a bad push address is refused and kept nowhere', async () => {
      const problems = [];
      const [, method, path] = /^([A-Z]+) (.*)$/.exec(o.push.route);
      const headers = ofAccount(o.push.as ?? 'user');
      const before = o.push.count ? await o.push.count() : null;
      await inTurn(BAD_PUSH_ENDPOINTS, async (endpoint) => {
        const r = await send(baseOf(), path, { method, headers, body: o.push.body(endpoint) });
        limited(r, path);
        if (r.status !== 400) problems.push(`${JSON.stringify(endpoint)} answered ${r.status}, not 400`);
      });
      if (o.push.count && (await o.push.count()) !== before) problems.push('a bad address was stored');
      const good = await send(baseOf(), path, { method, headers, body: o.push.body(GOOD_PUSH_ENDPOINTS[0]) });
      if (good.status < 200 || good.status >= 300) problems.push(`a good address answered ${good.status}, so the refusals prove nothing`);
      report('Push addresses taken', problems);
    });
  }

  if (o.headers) {
    add("the fleet's headers are on", async () => {
      const r = await send(baseOf(), o.headers.path ?? '/');
      const problems = [];
      const h = r.headers;
      if (o.headers.csp !== false && !/default-src|script-src/.test(String(h['content-security-policy'] ?? ''))) problems.push('no Content-Security-Policy');
      if (h['x-content-type-options'] !== 'nosniff') problems.push('no X-Content-Type-Options: nosniff');
      if (!h['x-frame-options'] && !/frame-ancestors/.test(String(h['content-security-policy'] ?? ''))) problems.push('nothing stops framing');
      if (h['x-powered-by']) problems.push('X-Powered-By is on');
      report('Headers', problems);
    });
  }

  return checks;
}
