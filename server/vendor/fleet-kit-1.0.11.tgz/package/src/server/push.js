// What a browser's push subscription may say. The server POSTs to the address it is given, so an
// app takes these checks at its subscribe route and again before each send.
import crypto from 'node:crypto';

// Only real browser push services.
const PUSH_HOSTS = [
  /\.push\.apple\.com$/,
  /^fcm\.googleapis\.com$/,
  /^android\.googleapis\.com$/,
  /^updates\.push\.services\.mozilla\.com$/,
  /\.notify\.windows\.com$/,
];

// A plain address only: https, a host of letters, digits, dots and dashes, then a path. web-push
// reads the address with the older url.parse, which ends the host at ; ' " { } and a backtick
// where new URL keeps going, so https://evil.example;.push.apple.com/x would pass a check on URL's
// hostname and be sent to evil.example, or to an address inside the network. No port or
// user:password either. This pattern can't be read two ways.
const PLAIN_ADDRESS = /^https:\/\/((?:[a-z0-9-]+\.)+[a-z0-9-]+)(?:\/\S*)?$/i;
const MAX_ENDPOINT = 2048;

/** Whether a subscription's endpoint is a real push service's plain address. */
export function isPushEndpoint(endpoint) {
  if (typeof endpoint !== 'string' || endpoint.length > MAX_ENDPOINT) return false;
  const host = PLAIN_ADDRESS.exec(endpoint)?.[1].toLowerCase();
  return Boolean(host) && PUSH_HOSTS.some((re) => re.test(host));
}

const B64URL = /^[A-Za-z0-9_-]+={0,2}$/;

/** A subscription's keys: an uncompressed P-256 public key and an auth secret of at least 16
 *  bytes. Junk keys fail every send without the 404/410 that would clean them up, so they are
 *  refused at the door. */
export function validPushKeys(p256dh, auth) {
  if (typeof p256dh !== 'string' || typeof auth !== 'string') return false;
  if (!B64URL.test(p256dh) || !B64URL.test(auth)) return false;
  if (Buffer.from(auth, 'base64url').length < 16) return false;
  if (Buffer.from(p256dh, 'base64url').length !== 65) return false;
  try {
    crypto.ECDH.convertKey(p256dh, 'prime256v1', 'base64url'); // throws if not on the curve
    return true;
  } catch {
    return false;
  }
}
