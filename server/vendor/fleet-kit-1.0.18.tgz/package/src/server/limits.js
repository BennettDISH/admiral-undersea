// Rate limits, in memory (a deploy starts every window over, which is fine for these apps).
//
// Every app reaches Waypoint from its one server address, and Waypoint caps per calling
// address: without a limit here, one visitor posting junk sign-ins used up the cap and locked
// every player out. So every route that calls Waypoint is limited per visitor, and so are
// break-glass passwords and public writes.
//
// The visitor is X-Real-IP when it holds one bare address: Railway's edge writes it over anything
// the client sent, and the games' front door passes it on. Without one (local runs, tests), req.ip
// with `trust proxy` set to 1: the last X-Forwarded-For entry. That entry is the visitor only
// through the front door; on an app's own Railway address it is a Railway hop, so many
// visitors counted as one there (seen live 2026-11-19). `true` would make req.ip the first entry,
// which the client writes itself. An IPv6 visitor usually holds a whole /64, so IPv6 counts by that.
import { isIP, isIPv6 } from 'node:net';

/**
 * The key to limit a visitor by. One IPv6 visitor usually holds a whole /64 (billions of
 * addresses), so IPv6 is counted by that prefix. IPv4, IPv4-mapped IPv6 (as plain IPv4) and the
 * rest of ::/80 (loopback) keep the full address.
 */
export function ipKey(ip) {
  const address = String(ip ?? 'unknown').split('%')[0].toLowerCase();
  if (!isIPv6(address)) return address;
  // Expand to eight 16-bit words; a dotted IPv4 tail is the last two.
  const words = (part) => (part ? part.split(':') : []).flatMap((g) => {
    if (!g.includes('.')) return [parseInt(g, 16)];
    const [a, b, c, d] = g.split('.').map(Number);
    return [a * 256 + b, c * 256 + d];
  });
  const [head, tail] = address.split('::');
  const left = words(head);
  const right = words(tail);
  const all = tail === undefined ? left : [...left, ...Array(8 - left.length - right.length).fill(0), ...right];
  if (all.slice(0, 5).some((w) => w !== 0)) {
    return `${all.slice(0, 4).map((w) => w.toString(16)).join(':')}::/64`;
  }
  if (all[5] === 0xffff) return [all[6] >> 8, all[6] & 255, all[7] >> 8, all[7] & 255].join('.');
  return address;
}

/** X-Real-IP from these request headers when it is one bare address, else null. A list, a
 *  second header (Node joins the two with a comma) or text around the address is no address. */
export function realIp(headers) {
  const real = headers?.['x-real-ip'];
  return typeof real === 'string' && isIP(real) ? real : null;
}

/** The visitor's address for a request: X-Real-IP (see the top of this file), else req.ip, else
 *  the connection's own. */
export const clientAddress = (req) => realIp(req.headers) ?? req.ip ?? req.socket?.remoteAddress ?? 'unknown';

/** The visitor's key for a request. */
export const clientKey = (req) => ipKey(clientAddress(req));

/**
 * Once `map` (least recently used first) holds more than `maxKeys`, its least recently used tenth
 * goes in one walk from the front. One key a time looked as cheap, but V8 keeps a deleted entry's
 * slot until it rebuilds the table, and each walk from the front steps over every one of them:
 * a flood of new keys then cost each hit several times a plain one (1.0.14).
 */
function forgetOldest(map, maxKeys) {
  if (map.size <= maxKeys) return;
  const keep = Math.max(1, maxKeys - Math.ceil(maxKeys / 10));
  for (const k of map.keys()) {
    if (map.size <= keep) break;
    map.delete(k);
  }
}

/**
 * A sliding window per key: `hit(key)` counts one and answers { ok, retryAfter, undo }, where
 * retryAfter is the seconds until a slot frees and undo() gives the slot back (a guest that was
 * never minted, say). Past `maxKeys` stored keys it forgets visitors whose window has passed,
 * then the ones seen least recently, so a flood of new keys can't reset everyone's limits.
 *
 * The forgetting stays cheap in a flood, which is when a limit matters most: the walk for passed
 * windows runs at most once a window, and in between the least recently seen tenth goes at once
 * (`forgetOldest`). Walking all the keys on every hit once full made each request of a flood of
 * new addresses slow (fixed in 1.0.14); letting one key go per hit still cost several times a
 * plain hit (fixed in 1.0.15).
 */
export function limiter({ windowMs, max, maxKeys = 10000, now = Date.now }) {
  if (!(windowMs > 0) || !(max > 0)) throw new Error('limiter needs windowMs and max');
  const hits = new Map(); // key -> times, oldest first
  let walked = -Infinity; // when the passed windows were last cleared out
  const recent = (key, at) => (hits.get(key) || []).filter((t) => at - t < windowMs);
  function hit(key) {
    const at = now();
    const times = recent(key, at);
    const ok = times.length < max;
    if (ok) times.push(at);
    // re-inserted so the Map runs from least to most recently seen
    hits.delete(key);
    hits.set(key, times);
    if (hits.size > maxKeys) {
      if (at - walked >= windowMs) {
        walked = at;
        for (const [k, t] of hits) if (!t.length || at - t[t.length - 1] >= windowMs) hits.delete(k);
      }
      forgetOldest(hits, maxKeys);
    }
    const retryAfter = ok ? 0 : Math.max(1, Math.ceil((times[times.length - max] + windowMs - at) / 1000));
    return {
      ok,
      retryAfter,
      undo() {
        if (!ok) return;
        const list = hits.get(key);
        const i = list ? list.lastIndexOf(at) : -1;
        if (i >= 0) list.splice(i, 1);
      },
    };
  }
  return { hit, size: () => hits.size };
}

/**
 * Middleware: at most `max` requests per `windowMs` per key, then 429 JSON { error: message }
 * with Retry-After. `key(req)` defaults to the visitor's address (pass the account to count a
 * table of players on one network apart). `onLimit(req, res)` answers instead when the caller is
 * a browser page rather than the app's own fetch (Retry-After is already set).
 */
export function rateLimit({ windowMs, max, message = 'Too many requests. Wait a few minutes and try again.', key = clientKey, onLimit, maxKeys } = {}) {
  const counts = limiter({ windowMs, max, maxKeys });
  const middleware = (req, res, next) => {
    const r = counts.hit(key(req));
    if (r.ok) return next();
    res.set('Retry-After', String(r.retryAfter));
    return onLimit ? onLimit(req, res) : res.status(429).json({ error: message });
  };
  middleware.limiter = counts;
  return middleware;
}

/** An amount per key for a fixed window: `room(key)` is what is left, `add(key, n)` spends n (a
 *  negative n gives it back), `resetIn(key)` is the seconds to the window's end. Daily upload
 *  bytes per account, say. Past `maxKeys` keys it forgets the ones whose window has ended (that
 *  walk at most once a window), then the ones that spent least recently, as `limiter` does. */
export function budget(windowMs, max, { now = Date.now, maxKeys = 10000 } = {}) {
  const spent = new Map(); // key -> { used, until }, least recently spent first
  let walked = -Infinity;
  const live = (key, at) => {
    const h = spent.get(key);
    return h && h.until > at ? h : null;
  };
  return {
    max,
    room: (key) => max - (live(key, now())?.used ?? 0),
    add(key, n) {
      const at = now();
      const h = live(key, at) ?? { used: 0, until: at + windowMs };
      h.used = Math.max(0, h.used + n);
      spent.delete(key);
      spent.set(key, h);
      if (spent.size > maxKeys) {
        if (at - walked >= windowMs) {
          walked = at;
          for (const [k, v] of spent) if (v.until <= at) spent.delete(k);
        }
        forgetOldest(spent, maxKeys);
      }
    },
    resetIn(key) {
      const h = live(key, now());
      return h ? Math.ceil((h.until - now()) / 1000) : 0;
    },
    size: () => spent.size,
  };
}

/** Trust the one proxy in front (the platform's edge) and only it. Call right after
 *  express(): req.protocol is then the browser's https, and req.ip the address limits count
 *  when a request has no X-Real-IP. */
export function trustOneProxy(app) {
  app.set('trust proxy', 1);
  return app;
}

/** Throws unless `trust proxy` is exactly 1: an app that trusts more counts a client-written
 *  address in every limit. For boot, after the app is set up. */
export function assertTrustProxy(app) {
  const setting = app.get('trust proxy');
  if (setting !== 1) throw new Error(`trust proxy must be 1 (one hop: the platform's edge), not ${JSON.stringify(setting)}`);
}
