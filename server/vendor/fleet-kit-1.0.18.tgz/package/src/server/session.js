// The session: an httpOnly __Host-<app>_session cookie the server sets, holding an HS256 token
// (jwt.js) with who it is and `tv`, the account's token_version when it was minted. Never a token
// in localStorage, which any script that gets onto the page can read.
//
// With `load`, every request reads the account's own row: a session whose tv is behind the row's
// (signed out since, on any device) is refused, and so is one whose row is gone (a swept guest).
// Without `load` (an app that keeps no accounts table) the token itself says who it is.
//
// Every token names its app (`aud`, the app code), and an app takes no other app's: `sub` is one
// app's own row, so where two apps share a secret, someone's row 1 there would be row 1 here,
// often the admin. Tokens from before 1.0.7 name no app. One minted before UNBOUND_BEFORE still
// counts until its own exp, one TTL at most, so nobody is signed out by the bump, and /me swaps
// it for one that names the app; once they have all run out that branch can go.
//
// Sessions slide: /me, which every page load asks, renews one older than a day, so only
// `ttlMs` without a visit ends it. `onRenew` runs then (stamp last_seen_at; the waypoint module
// also tells Waypoint a guest is still in use, or Waypoint forgets it after a month).
//
// Moving an app onto this session without signing anyone out: `legacy` readers take the old
// cookie (or, once, the old bearer token) and say who it is; the kit sets its own cookie in its
// place and clears the old one. A reader that also gives `exp` (seconds) keeps that end: the
// swap never makes a session last longer than it would have. A token that names another app never
// reaches a reader, which would only see the secret it shares.
//
// Who is the site admin: ADMIN_CENTRAL_USER_IDS by default (admin.js). An app with admins of its
// own passes `isAdmin(user, { listed })`, sync or async, answering true for an admin (`listed` is
// the default answer, to keep the list and add to it). A guest is never an admin, whatever the
// hook says; a hook that throws, or answers anything but true, means no.
//
// View as (viewAs.js): with `viewAs`, the site admin may look at the app as another account. The
// admin's own session is untouched; resolve answers the viewed account as req.user, and refuses
// every write while it does, unless `viewAs.writes(req)` says yes.
import crypto from 'node:crypto';
import { signJwt, verifyJwt } from './jwt.js';
import { cookieOpts, hostCookie, readCookie } from './cookies.js';
import { isAdmin } from './admin.js';
import { wrap, httpError } from './errors.js';
import { VIEWED, viewKeyOf, viewOptions, viewEvent, isWrite } from './viewAs.js';

const DAY_MS = 24 * 60 * 60 * 1000;
const RESERVED = new Set(['sub', 'cid', 'name', 'guest', 'tv', 'aud', 'iat', 'exp', 'nbf']);

/** A token that names no app counts only if it was minted before this: by then every app is on
 *  1.0.7, so nothing should still mint one, and the last of them is gone one TTL later. */
export const UNBOUND_BEFORE = Date.UTC(2026, 11, 1);

const bearerOf = (req) => {
  const h = req.headers?.authorization;
  return typeof h === 'string' && h.startsWith('Bearer ') ? h.slice(7).trim() : null;
};

/** The app a token names, read without checking it: only ever a reason to refuse. Not a JWT (an
 *  old format of an app's own) names none. */
function audOf(token) {
  try {
    return JSON.parse(Buffer.from(String(token).split('.')[1], 'base64url').toString('utf8'))?.aud;
  } catch {
    return undefined;
  }
}

/** The token's claims for an account (the app's row, or what onSignIn returned): sub (the row's
 *  id, else the central id), cid, name, guest, tv, plus whatever `extra(user)` adds. */
export function claimsOf(user, extra) {
  // the account someone is viewing as never gets a session of its own, by any road
  if (user?.[VIEWED]) throw new Error('fleet-kit: no session is made for an account being viewed as');
  const more = extra ? extra(user) || {} : {};
  for (const k of Object.keys(more)) if (RESERVED.has(k)) throw new Error(`session claim "${k}" is the kit's own`);
  return {
    ...more,
    sub: String(user.id ?? user.central_user_id),
    cid: user.central_user_id ?? null,
    name: user.username ?? user.name ?? null,
    guest: Boolean(user.is_guest),
    tv: Number(user.token_version ?? 0),
  };
}

/** The account a token names, when the app has no row to read. */
export function userFromClaims(claims) {
  const extra = Object.fromEntries(Object.entries(claims).filter(([k]) => !RESERVED.has(k)));
  return { ...extra, id: claims.sub, central_user_id: claims.cid ?? null, username: claims.name ?? null, is_guest: Boolean(claims.guest), token_version: Number(claims.tv ?? 0) };
}

export function createSession({
  app,
  secret,
  env = process.env,
  ttlMs = 30 * DAY_MS,
  slide = true,
  renewAfterMs = DAY_MS,
  load,
  claims: extraClaims,
  legacy = [],
  onRenew,
  onSignOut,
  isAdmin: adminHook,
  viewAs,
  now = Date.now,
} = {}) {
  if (typeof app !== 'string' || !/^[a-z][a-z0-9-]{0,23}$/i.test(app)) throw new Error('createSession needs a short app code, like "sf"');
  if (adminHook !== undefined && typeof adminHook !== 'function') throw new Error('isAdmin must be a function (user, { listed }) => true for an admin');
  const name = hostCookie(app, 'session');
  const view = viewOptions(viewAs);
  const viewName = hostCookie(app, 'view');
  const viewAud = `${app}:view`;

  /** Whether an account is the site admin: the hook's word when there is one (awaited), else the
   *  list. Never a guest; a failing hook is a no. */
  async function adminOf(user) {
    if (!user || user.is_guest) return false;
    const listed = isAdmin(user, env);
    if (!adminHook) return listed;
    try {
      return (await adminHook(user, { listed })) === true;
    } catch (err) {
      console.error('Admin check failed:', err?.message ?? err);
      return false;
    }
  }
  /** The same without waiting (a socket upgrade): an async hook's answer is not there yet, so it
   *  counts as no. */
  function adminOfNow(user) {
    if (!user || user.is_guest) return false;
    const listed = isAdmin(user, env);
    if (!adminHook) return listed;
    try {
      const answer = adminHook(user, { listed });
      if (answer && typeof answer.then === 'function') {
        answer.then(null, () => {});
        return false;
      }
      return answer === true;
    } catch {
      return false;
    }
  }
  // read when used, so a server that starts without it says so per request instead of crashing
  const key = () => secret || env.SESSION_SECRET || env.JWT_SECRET || '';
  const ttlFor = (user) => (typeof ttlMs === 'function' ? ttlMs(user) : ttlMs);
  const clearLegacy = (res, l) => {
    if (l?.cookie && l.cookie !== name) res.clearCookie(l.cookie, l.clearOpts ?? cookieOpts());
  };
  /** Whether verified claims are for this app: named, or dated and from before tokens named one. */
  const forThisApp = (c) =>
    c.aud === undefined ? typeof c.exp === 'number' && typeof c.iat === 'number' && c.iat * 1000 < UNBOUND_BEFORE : c.aud === app;

  function mint(user, { ttl } = {}) {
    return signJwt({ ...claimsOf(user, extraClaims), aud: app }, key(), { ttlMs: ttl ?? ttlFor(user), now: now() });
  }
  function set(res, user, { ttl = ttlFor(user) } = {}) {
    res.cookie(name, mint(user, { ttl }), cookieOpts({ maxAge: ttl }));
  }
  function clear(res) {
    res.clearCookie(name, cookieOpts());
    for (const l of legacy) clearLegacy(res, l);
    if (view) res.clearCookie(viewName, cookieOpts());
  }

  // ---- view as (viewAs.js) ----
  const viewKey = () => {
    const k = key();
    return k ? viewKeyOf(k) : '';
  };
  /** The site admin by the list (never an app's own admins) and by the app's own answer too. */
  const superAdmin = (user) => Boolean(user) && !user.is_guest && isAdmin(user, env) && user.is_admin === true;
  /** The view cookie: { claims } when it is this app's and its signature holds, with `expired`
   *  once its time is up; { bad } for anything else; null when there is none. */
  function readView(req) {
    if (!view) return null;
    const raw = readCookie(req, viewName);
    if (!raw) return null;
    const k = viewKey();
    // the signature alone first (now 0), so a view that ran out can be told from a forged one
    const c = k ? verifyJwt(raw, k, { now: 0 }) : null;
    if (!c || c.typ !== 'view' || c.aud !== viewAud || typeof c.exp !== 'number' || typeof c.by !== 'string'
      || !c.who || typeof c.who !== 'object' || Array.isArray(c.who) || c.who.sub === undefined || c.who.sub === null) return { bad: true };
    return { claims: c, expired: c.exp * 1000 <= now() };
  }
  /** Takes the view cookie away (once per request) and says why, unless it was nothing. */
  function dropView(req, res, why, { by, claims } = {}) {
    if (req.fleetViewDropped) return;
    req.fleetViewDropped = true;
    if (res && !res.headersSent) res.clearCookie(viewName, cookieOpts());
    const whom = claims?.who ? userFromClaims(claims.who) : null;
    if (why === 'expired') logView('ended', { why: 'time ran out', by, whom, req });
    else logView('refused', { why, by, whom, req });
  }
  const viewedName = (u) => view.name(u);
  const logView = (event, o) => viewEvent(app, view, event, { ...o, now });

  /** The session a request carries, if its signature and date hold: { claims, legacy }, or null.
   *  Synchronous and reads no database (a WebSocket upgrade can use it); whether it was signed
   *  out since is the row's to say (resolve). */
  function read(req) {
    const k = key();
    if (!k) return null;
    const raw = readCookie(req, name);
    const mine = raw ? verifyJwt(raw, k, { now: now() }) : null;
    if (mine && mine.sub !== undefined && forThisApp(mine)) return { claims: mine, legacy: null };
    for (const l of legacy) {
      const value = l.cookie ? readCookie(req, l.cookie) : l.bearer ? bearerOf(req) : null;
      if (!value) continue;
      const named = audOf(value);
      if (named !== undefined && named !== app) continue;
      let got = null;
      try {
        got = l.read(value, req);
      } catch {
        got = null;
      }
      if (got && got.sub !== undefined && got.sub !== null) return { claims: got, legacy: l };
    }
    return null;
  }

  /** Who is asking, once per request: { user } (null when signed out), with `failed` when the
   *  row could not be read (answer 500: a database restart must not sign the table out). Sets
   *  req.user. A legacy session is swapped for the kit's own cookie on the way. */
  async function resolve(req, res) {
    if (req.fleetSession) return req.fleetSession;
    const done = (r) => {
      req.fleetSession = r;
      req.user = r.user ?? null;
      return r;
    };
    const found = read(req);
    // a view cookie with no live session of its admin's is nothing; it goes
    const noView = () => {
      if (view && readCookie(req, viewName)) dropView(req, res, 'no session of its own');
    };
    if (!found) {
      noView();
      return done({ user: null, claims: null });
    }
    let user;
    if (load) {
      try {
        user = await load(found.claims, req);
      } catch (err) {
        console.error('Session check failed:', err?.message ?? err);
        return done({ user: null, claims: found.claims, failed: true });
      }
      // a session from before token_version carries no number: it is version 0, like its row
      if (user && Number(found.claims.tv ?? 0) !== Number(user.token_version ?? 0)) user = null;
    } else {
      user = userFromClaims(found.claims);
    }
    // a legacy session keeps the end it had (its exp, in seconds): swapped, never extended
    const left = found.legacy && typeof found.claims.exp === 'number' ? found.claims.exp * 1000 - now() : null;
    if (!user || (left !== null && left <= 0)) {
      noView();
      return done({ user: null, claims: found.claims, dead: true });
    }
    user = { ...user, is_admin: await adminOf(user) };
    const real = { user, claims: found.claims };
    if (view && !found.legacy) {
      const viewed = await viewOf(req, res, real);
      if (viewed?.failed) return done({ user: null, claims: found.claims, failed: true });
      if (viewed) return done(viewed);
    } else if (view && readCookie(req, viewName)) {
      dropView(req, res, 'a session from before the kit');
    }
    const r = done({ user, claims: found.claims, legacy: found.legacy, real });
    if (found.legacy && res && !res.headersSent) {
      set(res, user, left !== null ? { ttl: Math.min(ttlFor(user), left) } : undefined);
      clearLegacy(res, found.legacy);
      r.upgraded = true;
    }
    return r;
  }

  /** The view a request carries, for the admin it belongs to: the result resolve answers (the
   *  viewed account, or nobody for a write), or null to go on as the admin; { failed } when the
   *  viewed account's row could not be read. A view cookie anyone else carries is dropped. */
  async function viewOf(req, res, real) {
    const v = readView(req);
    if (!v) return null;
    const by = real.user;
    if (v.bad) return dropView(req, res, 'a view cookie that does not verify', { by }), null;
    if (v.expired) return dropView(req, res, 'expired', { by, claims: v.claims }), null;
    if (!superAdmin(by)) return dropView(req, res, 'not the site admin', { by, claims: v.claims }), null;
    if (v.claims.by !== String(real.claims.sub) || Number(v.claims.btv) !== Number(real.claims.tv ?? 0)) {
      return dropView(req, res, "another session's view", { by, claims: v.claims }), null;
    }
    const who = v.claims.who;
    let target;
    if (load) {
      try {
        target = await load(who, req);
      } catch (err) {
        console.error('Session check failed (view as):', err?.message ?? err);
        return { failed: true };
      }
    } else {
      target = userFromClaims(who);
    }
    if (!target) return dropView(req, res, 'the account is gone', { by, claims: v.claims }), null;
    if (target.is_guest !== true && (isAdmin(target, env) || (await adminOf(target)))) {
      return dropView(req, res, 'that account is an admin', { by, claims: v.claims }), null;
    }
    const viewed = { ...target, is_admin: false, [VIEWED]: true };
    const until = v.claims.exp * 1000;
    const viewing = { by, whom: viewed, name: viewedName(viewed), until };
    req.viewAs = {
      by: { id: by.id ?? null, central_user_id: by.central_user_id ?? null, username: by.username ?? null },
      name: viewing.name,
      until,
    };
    // read-only: a write gets nobody, so whatever the app asks the session, it is not theirs
    if (isWrite(req) && !view.writes(req)) return { user: null, claims: who, real, viewing, readOnly: true };
    return { user: viewed, claims: who, real, viewing };
  }

  /** The account without a database read: for a socket upgrade in an app with no `load`. An
   *  async isAdmin hook cannot answer here, so is_admin is false then: use resolve for that.
   *  While a view is on, nobody: a socket can't be held to read-only. */
  function peek(req) {
    const found = read(req);
    if (!found) return null;
    const v = readView(req);
    if (v && !v.bad && !v.expired) return null;
    const user = load ? null : userFromClaims(found.claims);
    return user ? { ...user, is_admin: adminOfNow(user) } : null;
  }

  /** The refusal of a write while viewing as someone. */
  const refuseWhileViewing = (res, r) => res.status(403).json({
    error: `You're viewing as ${r.viewing?.name ?? 'someone'}, so nothing can be changed. Exit to make changes.`,
    code: 'viewing_as',
  });

  /** Sets req.user (null when signed out) and goes on; 500 when the row could not be read; 403 for
   *  a write while viewing as someone (but the kit's own start, Exit and sign-out). */
  const loadUser = wrap(async (req, res, next) => {
    const r = await resolve(req, res);
    if (r.failed) return res.status(500).json({ error: 'Could not check your session. Try again.' });
    if (r.readOnly && !view.exempt(req)) return refuseWhileViewing(res, r);
    next();
  });

  /** loadUser, then 401 for no session. What it lets through is private, so the browser doesn't
   *  keep it, unless the route says otherwise (res.set after this). */
  const requireUser = wrap(async (req, res, next) => {
    res.setHeader?.('Cache-Control', 'no-store'); // a hand call may pass a small stand-in
    const r = await resolve(req, res);
    if (r.failed) return res.status(500).json({ error: 'Could not check your session. Try again.' });
    if (r.readOnly) return refuseWhileViewing(res, r);
    if (!r.user) return res.status(401).json({ error: 'Not signed in' });
    next();
  });

  /** Renews a live session minted more than renewAfterMs ago, or one that names no app yet.
   *  Returns whether it did. While viewing as someone it is the admin's own session that renews. */
  async function renew(req, res) {
    const r = await resolve(req, res);
    const own = r.real ?? r;
    if (!slide || !own.user || r.upgraded || typeof own.claims?.iat !== 'number') return false;
    const unbound = own.claims.aud === undefined && !r.legacy;
    if (!unbound && now() - own.claims.iat * 1000 < renewAfterMs) return false;
    set(res, own.user);
    if (onRenew) {
      try {
        await onRenew(own.user, req);
      } catch (err) {
        console.error('Session renewal hook failed:', err?.message ?? err);
      }
    }
    return true;
  }

  /** Ends the session: `onSignOut(claims)` first (add one to the row's token_version, which
   *  refuses this cookie, any copy of it and every other device's), then the cookie. If
   *  onSignOut throws, the cookie stays and the caller says so: a sign-out that failed leaves
   *  the page signed in and able to try again. A view the admin had on ends with it. */
  async function signOut(req, res) {
    const found = read(req);
    if (found && onSignOut) await onSignOut(found.claims, req);
    const v = readView(req);
    if (found && v?.claims && !v.expired && v.claims.by === String(found.claims.sub)) {
      logView('ended', { why: 'signed out', by: userFromClaims(found.claims), whom: userFromClaims(v.claims.who), req });
    }
    clear(res);
  }

  /** Starts viewing as `target` (a row, as `load` answers) for the admin signed in on this request:
   *  sets the view cookie and answers { name, until }. Throws an HttpError (4xx) for anyone but
   *  the site admin, for the admin's own account, and for another admin. */
  async function startView(req, res, target) {
    if (!view) throw new Error('startView needs createSession({ viewAs })');
    const r = await resolve(req, res);
    if (r.failed) throw Object.assign(new Error('Could not check your session'), { status: 500, expose: false });
    const real = r.real;
    if (!real?.user) {
      logView('refused', { why: 'signed out', req });
      throw httpError(401, 'Not signed in');
    }
    if (r.legacy || !superAdmin(real.user)) {
      logView('refused', { why: 'not the site admin', by: real.user, req });
      throw httpError(403, 'Only the site admin can view as someone.');
    }
    if (!target) throw httpError(404, 'No such account');
    const who = claimsOf(target, extraClaims);
    if (who.sub === String(real.claims.sub) || (who.cid != null && String(who.cid) === String(real.user.central_user_id))) {
      throw httpError(400, "That's your own account.");
    }
    if (target.is_guest !== true && (isAdmin(target, env) || (await adminOf(target)))) {
      logView('refused', { why: 'that account is an admin', by: real.user, whom: target, req });
      throw httpError(403, "An admin can't be viewed as.");
    }
    const k = viewKey();
    if (!k) throw Object.assign(new Error('No session secret'), { status: 500, expose: false });
    const token = signJwt({
      typ: 'view',
      aud: viewAud,
      jti: crypto.randomBytes(9).toString('base64url'),
      by: String(real.claims.sub),
      btv: Number(real.claims.tv ?? 0),
      who,
    }, k, { ttlMs: view.ttlMs, now: now() });
    const until = (Math.floor(now() / 1000) + Math.floor(view.ttlMs / 1000)) * 1000;
    res.cookie(viewName, token, cookieOpts({ maxAge: view.ttlMs }));
    const name = viewedName({ ...target, is_admin: false });
    logView('started', { by: real.user, whom: target, until, req });
    return { name, until };
  }

  /** Exit: the view cookie goes and the admin's own session is back. Says who stopped viewing as
   *  whom when the cookie was a real one. Anyone may clear their own cookie. */
  async function endView(req, res, why = 'exit') {
    if (!view) return false;
    const v = readView(req);
    res.clearCookie(viewName, cookieOpts());
    if (!v?.claims || v.expired) return false;
    const found = read(req);
    const by = found && v.claims.by === String(found.claims.sub) ? userFromClaims(found.claims) : { id: v.claims.by };
    logView('ended', { why, by, whom: userFromClaims(v.claims.who), req });
    return true;
  }

  return {
    name, viewName, cookieOpts, mint, set, clear, read, peek, resolve, loadUser, requireUser, renew, signOut, userFromClaims,
    isAdmin: adminOf, isAdminNow: adminOfNow, isSuperAdmin: superAdmin, startView, endView, viewing: Boolean(view),
  };
}
