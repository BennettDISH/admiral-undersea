// View as: the site admin sees the app the way one of its people sees it, to help them.
//
// Only the admin on ADMIN_CENTRAL_USER_IDS starts one (never an app's own admins, never a guest),
// from /admin, by picking an account (createWaypoint's `viewAs`). The admin's own session stays as
// it is. A second cookie, __Host-<app>_view, names whom they are viewing as. It is signed with a key
// of its own, never the session's, so neither can pass for the other, and it is tied to that admin's
// session: their account (sub) and their token_version, so a sign-out anywhere ends it. Every
// request asks again: the session must still be that admin's, and they must still be on the list.
// Anyone else carrying the cookie (copied, replayed, altered, forged, or with a session of their own)
// is just themselves, and the cookie is cleared.
//
// It is read-only. A write while viewing is refused (403, code viewing_as) before it reaches the app,
// and anything that asks the session who is writing gets nobody. An app may let chosen writes
// through (`writes(req)`), and then they are the viewed account's. It ends on its own after `ttlMs`
// (30 minutes, 2 hours at most), on Exit, and on sign-out, and the admin's own session is back at
// once, untouched. Every start and stop is a log line saying who, whom and when, never a token.
//
// While viewing, req.user is the viewed account (is_admin false, whatever it is elsewhere) and
// req.viewAs says so: { by, name, until }. No session is ever made for that account: claimsOf,
// mint and set refuse it.
import crypto from 'node:crypto';

export const VIEW_TTL_MS = 30 * 60 * 1000;
export const MAX_VIEW_TTL_MS = 2 * 60 * 60 * 1000;
const MIN_VIEW_TTL_MS = 60 * 1000;

/** On the account req.user holds while viewing: enumerable, so a copy made with {...user} keeps it,
 *  and a symbol, so JSON (and so the page) never sees it. */
export const VIEWED = Symbol.for('fleet-kit.viewed');

const READS = new Set(['GET', 'HEAD', 'OPTIONS']);
export const isWrite = (req) => !READS.has(String(req?.method ?? 'GET').toUpperCase());

/** The view cookie's key: from the session secret, never the secret itself. */
export const viewKeyOf = (secret) => crypto.createHmac('sha256', String(secret)).update('fleet-kit view-as v1').digest('hex');

/** An id a start may name: a positive whole number, or up to 64 letters, digits, _ and -. */
export const viewId = (id) => (Number.isSafeInteger(id) && id > 0) || (typeof id === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(id));

const defaultName = (u) => {
  const full = [u?.first_name, u?.last_name].filter((s) => typeof s === 'string' && s.trim()).join(' ').trim();
  return String(u?.display_name || u?.name || full || u?.username || 'this account').slice(0, 80);
};

/** createSession's `viewAs`, filled in: off when not given. */
export function viewOptions(o) {
  if (!o) return null;
  if (o.writes !== undefined && typeof o.writes !== 'function' && o.writes !== false) throw new Error('viewAs.writes must be (req) => true for a write that may go through while viewing');
  if (o.name !== undefined && typeof o.name !== 'function') throw new Error('viewAs.name must be (user) => the name the banner shows');
  if (o.onEvent !== undefined && typeof o.onEvent !== 'function') throw new Error('viewAs.onEvent must be a function');
  const ttl = Number(o.ttlMs ?? VIEW_TTL_MS);
  if (!Number.isFinite(ttl) || ttl < MIN_VIEW_TTL_MS || ttl > MAX_VIEW_TTL_MS) throw new Error(`viewAs.ttlMs must be between ${MIN_VIEW_TTL_MS} and ${MAX_VIEW_TTL_MS}`);
  const exempt = (o.exempt ?? []).map((p) => String(p).toLowerCase());
  const writes = typeof o.writes === 'function' ? o.writes : () => false;
  return {
    ttlMs: ttl,
    name: (u) => {
      try {
        return String((o.name ?? defaultName)(u) || defaultName(u)).slice(0, 80);
      } catch {
        return defaultName(u);
      }
    },
    /** Whether this write may go through as the viewed account: only the app's yes, never a throw. */
    writes: (req) => {
      try {
        return writes(req) === true;
      } catch {
        return false;
      }
    },
    onEvent: o.onEvent,
    /** The kit's own writes that answer while viewing (start, Exit, sign-out): they act for the
     *  admin, and req.user is still nobody there. Only these exact paths. */
    exempt: (req) => exempt.includes(String(req.originalUrl ?? req.url ?? '').split('?')[0].toLowerCase()),
  };
}

const who = (u) => (u ? `account ${u.id ?? '?'} (central ${u.central_user_id ?? '?'}${u.username ? `, ${u.username}` : ''})` : 'nobody');

/** The log line for a start, stop or refusal, and the app's onEvent. Who and whom by id and
 *  username, the time, the request's id; never a cookie or token. */
export function viewEvent(app, view, event, { by, whom, until, why, req, now = Date.now } = {}) {
  const at = new Date(now());
  const parts = [`fleet-kit view-as [${app}] ${event}${why ? ` (${why})` : ''}: ${event === 'refused' ? 'asked by' : 'admin'} ${who(by)}`];
  if (whom) parts.push(`${event === 'started' ? 'is viewing as' : 'viewing as'} ${who(whom)}`);
  if (until) parts.push(`until ${new Date(until).toISOString()}`);
  parts.push(`at ${at.toISOString()}${req?.id ? `, request ${req.id}` : ''}`);
  (event === 'refused' ? console.error : console.log)(parts.join(' '));
  if (!view?.onEvent) return;
  const plain = (u) => (u ? { id: u.id ?? null, central_user_id: u.central_user_id ?? null, username: u.username ?? null } : null);
  try {
    const out = view.onEvent({ event, why: why ?? null, by: plain(by), whom: plain(whom), at, until: until ? new Date(until) : null });
    if (out && typeof out.then === 'function') out.then(null, (err) => console.error('viewAs.onEvent failed:', err?.message ?? err));
  } catch (err) {
    console.error('viewAs.onEvent failed:', err?.message ?? err);
  }
}

/** The page for /admin while viewing as someone: whose view this is, the banner, and the way out:
 *  a link to Exit's GET, which an app's JSON-only guard on its writes can't refuse, as it would a
 *  form (Maintainer's did, 1.0.17). */
export function viewingPage({ appName = 'the site', name, exitPath }) {
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const banner = String(exitPath).replace(/\/exit$/, '.js');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Viewing as ${esc(name)} · ${esc(appName)}</title><meta name="robots" content="noindex">
<script src="${esc(banner)}" defer></script></head>
<body style="font:16px/1.5 system-ui,sans-serif;max-width:32rem;margin:4rem auto;padding:0 1rem">
<h1 style="font-size:1.4rem">You're viewing ${esc(appName)} as ${esc(name)}.</h1>
<p>The admin pages are yours, not theirs. Exit to go back to them.</p>
<p><a href="${esc(exitPath)}">Exit</a></p>
</body></html>
`;
}

/** The banner, served at <mount>/view-as.js: a page that loads it shows "Viewing as <name>: Exit"
 *  across the top while the admin views as someone, and nothing otherwise. No inline style or
 *  script, so it passes a strict CSP (script-src 'self'). */
export const BANNER_JS = `// fleet-kit view-as banner
(function () {
  'use strict';
  var me = document.currentScript;
  var base = '/api/auth';
  try {
    if (me && me.src) base = new URL(me.src, location.href).pathname.replace(/\\/view-as\\.js$/, '');
  } catch (e) { /* keep the default */ }
  var ID = 'fleet-view-as';
  function clock(t) {
    try {
      return new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    } catch (e) {
      return '';
    }
  }
  function draw(v) {
    if (document.getElementById(ID)) return;
    var bar = document.createElement('div');
    bar.id = ID;
    bar.setAttribute('role', 'status');
    bar.setAttribute('aria-live', 'polite');
    var s = bar.style;
    s.position = 'fixed';
    s.top = '0';
    s.left = '0';
    s.right = '0';
    s.zIndex = '2147483647';
    s.display = 'flex';
    s.flexWrap = 'wrap';
    s.alignItems = 'center';
    s.justifyContent = 'center';
    s.gap = '4px 12px';
    s.padding = '6px 12px';
    s.background = '#c4001a';
    s.color = '#fff';
    s.font = '600 15px/1.3 system-ui, -apple-system, Segoe UI, sans-serif';
    s.boxShadow = '0 2px 10px rgba(0,0,0,.35)';
    s.textAlign = 'center';
    var text = document.createElement('span');
    var end = clock(v.until);
    text.textContent = 'Viewing as ' + v.name + (end ? ' (read-only, ends ' + end + ')' : ' (read-only)');
    var exit = document.createElement('button');
    exit.type = 'button';
    exit.textContent = 'Exit';
    var b = exit.style;
    b.background = '#fff';
    b.color = '#c4001a';
    b.border = '0';
    b.borderRadius = '999px';
    b.padding = '4px 16px';
    b.minHeight = '32px';
    b.font = 'inherit';
    b.cursor = 'pointer';
    exit.addEventListener('click', function () {
      exit.disabled = true;
      fetch(v.exit, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: '{}' })
        .then(function (r) { return r.json(); })
        .then(function (a) { location.assign((a && a.next) || '/'); }, function () { location.reload(); });
    });
    bar.appendChild(text);
    bar.appendChild(exit);
    document.body.appendChild(bar);
    var h = Math.ceil(bar.getBoundingClientRect().height);
    var pad = parseFloat(getComputedStyle(document.body).paddingTop) || 0;
    document.body.style.paddingTop = pad + h + 'px';
    document.documentElement.style.setProperty('--fleet-view-as-height', h + 'px');
    // a page that redraws the whole body still shows it
    setInterval(function () { if (!document.getElementById(ID)) document.body.appendChild(bar); }, 2000);
    // when it runs out, the page is the admin's own again
    setTimeout(function () { location.reload(); }, Math.max(1000, Number(v.until) - Date.now() + 1000));
  }
  fetch(base + '/view-as', { credentials: 'same-origin', headers: { Accept: 'application/json' } })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (a) {
      if (!a || !a.viewing) return;
      if (document.body) draw(a.viewing);
      else document.addEventListener('DOMContentLoaded', function () { draw(a.viewing); });
    }, function () {});
})();
`;
