// An app as a confidential OAuth client of Waypoint, the sign-in service the apps share, the
// way its canonical guide has it (auth-service docs, ADDING-SSO-TO-AN-APP): client_id and
// client_secret stay on the server; the authorize URL is built here; the code is exchanged
// server to server; the session is the app's own cookie (session.js).
//
//   const wp = createWaypoint({ app: 'sf', guests: 'allow', onSignIn: upsertUser, session: { load } });
//   app.use('/api/auth', wp.router);  // config, sso/login, sso/callback, me, logout, logout-all, guest, ...
//   app.use(wp.session.loadUser);     // req.user from the cookie
//
// Env (names fixed by the kit): AUTH_SERVICE_URL, SSO_CLIENT_ID, SSO_CLIENT_SECRET, APP_BASE_URL
// (optional: pins the address Waypoint sends the browser back to), SESSION_SECRET or JWT_SECRET,
// ADMIN_CENTRAL_USER_IDS.
import crypto from 'node:crypto';
import express from 'express';
import { cookieOpts, hostCookie, readCookie } from './cookies.js';
import { createSession } from './session.js';
import { adminPage, plainPage } from './admin.js';
import { wrap } from './errors.js';
import { clientKey, limiter, rateLimit } from './limits.js';
import { sameOriginWrites } from './sameOrigin.js';
import { checkGuests } from './guestCheck.js';

const MINUTE = 60 * 1000;
const STATE_TTL_MS = 10 * MINUTE;

/** A page on this site to come back to, never another: one leading /, no // or backslash, no
 *  control characters, under 500 characters. Anything else is '/'. */
export const safeNext = (next) =>
  typeof next === 'string' && next.length < 500 && /^\/(?![/\\])/.test(next) && !/[\\\u0000-\u001f\u007f]/.test(next) ? next : '/';

/** Waypoint's answers are flat (central_user_id, username, email, ...), the same shape from
 *  /oauth/token and every /api/auth/proxy route; there is no nested `user`. An email is a
 *  string or null, never '' (a blank is not an address). */
export function waypointUser(info, { guest } = {}) {
  const email = typeof info?.email === 'string' && info.email.trim() ? info.email.trim() : null;
  return {
    central_user_id: info.central_user_id,
    username: info.username ?? null,
    email,
    first_name: info.first_name ?? null,
    last_name: info.last_name ?? null,
    is_guest: guest ?? info.is_guest === true,
  };
}

/** Waypoint, server to server. Every call has a time limit; a hung Waypoint must not hold a
 *  player's sign-in open until the platform drops the request. */
export function waypointClient({ env = process.env, timeoutMs = 10_000, fetchImpl } = {}) {
  const url = () => String(env.AUTH_SERVICE_URL || '').trim().replace(/\/+$/, '');
  const id = () => env.SSO_CLIENT_ID || '';
  const secret = () => env.SSO_CLIENT_SECRET || '';
  const configured = () => Boolean(url() && id() && secret());
  // looked up per call, so a test's stand-in for global fetch is the one used
  const doFetch = (...args) => (fetchImpl ?? globalThis.fetch)(...args);
  const send = async (path, body) => {
    const res = await doFetch(`${url()}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    return { status: res.status, json: await res.json().catch(() => null) };
  };
  /** One of Waypoint's proxy routes (/api/auth/proxy/login, register, guest, claim, seen):
   *  resolves { status, json }; throws only when Waypoint could not be reached at all. */
  const proxy = (path, body = {}) => send(path, { client_id: id(), client_secret: secret(), ...body });
  return {
    url,
    configured,
    proxy,
    authorizeUrl({ redirectUri, state, prompt, guests }) {
      const u = new URL(`${url()}/oauth/authorize`);
      u.searchParams.set('client_id', id());
      u.searchParams.set('redirect_uri', redirectUri);
      u.searchParams.set('state', state);
      // Switch account: Waypoint asks who you are instead of reusing its own session.
      // Create an account: Waypoint's sign-up form, which comes back here signed in.
      if (prompt === 'login' || prompt === 'create') u.searchParams.set('prompt', prompt);
      // An app that refuses guests: Waypoint's page offers no guest start (the callback still
      // refuses a guest; this only spares people the dead end)
      if (guests === 'refuse') u.searchParams.set('guests', 'refuse');
      return u.toString();
    },
    exchange: (code, redirectUri) =>
      send('/oauth/token', { grant_type: 'authorization_code', code, client_id: id(), client_secret: secret(), redirect_uri: redirectUri }),
    guest: () => proxy('/api/auth/proxy/guest'),
    login: (email, password) => proxy('/api/auth/proxy/login', { email, password }),
    register: ({ username, email, password, first_name, last_name }) =>
      proxy('/api/auth/proxy/register', { username, email, password, first_name, last_name }),
    claim: ({ central_user_id, username, password, email }) => proxy('/api/auth/proxy/claim', { central_user_id, username, password, email }),
    /** Tell Waypoint a guest is still in use: its sweep deletes an unclaimed guest it has not
     *  seen sign in for a month, and a sliding session never signs in there again. Never throws. */
    async reportSeen(centralUserId) {
      if (!configured()) return { ok: false, status: 0 };
      try {
        const r = await proxy('/api/auth/proxy/seen', { central_user_id: centralUserId });
        if (r.status !== 200) console.error(`Waypoint did not take guest ${centralUserId}'s activity: ${r.status}`);
        return { ok: r.status === 200, status: r.status };
      } catch (err) {
        console.error('Waypoint unreachable for proxy/seen:', err?.message ?? err);
        return { ok: false, status: 0 };
      }
    },
    checkGuests: (ids, opts = {}) => checkGuests(ids, { env, ...(fetchImpl ? { fetchImpl } : {}), ...opts }),
    /** Waypoint's own sign-out page: only Waypoint can end its session, on its origin. It
     *  follows return_to only to a registered app's origin. */
    logoutUrl(returnTo) {
      const u = new URL(`${url()}/logout`);
      if (returnTo) u.searchParams.set('return_to', returnTo);
      return u.toString();
    },
  };
}

/** What /me and the sign-in answers hand the page: what it shows and decides by, not the
 *  session's bookkeeping. */
export const defaultPublicUser = (u) => ({
  id: u.id,
  central_user_id: u.central_user_id,
  username: u.username ?? null,
  email: u.email ?? null,
  is_guest: Boolean(u.is_guest),
  is_admin: Boolean(u.is_admin),
});

// Waypoint's refusals, said as what they are: a rate limit and an outage are not a wrong password
function refusal(r, credentialsMessage) {
  if (r.status === 429) return [429, 'Too many sign-in attempts. Wait a few minutes and try again.'];
  if (r.status >= 500) return [502, 'The sign-in service is having trouble. Try again shortly.'];
  if (r.status === 401) return [401, credentialsMessage];
  return [r.status >= 400 && r.status < 500 ? r.status : 400, r.json?.error || credentialsMessage];
}

const GUEST_REFUSED = "Guest accounts can't be used here. Sign in with your own account.";

// Options beyond the obvious: publicUser(user, req) shapes the account for /me and the sign-in
// answers, and may be async (an answer that needs the database); isAdmin(user, { listed }) gives
// an app admins of its own (see session.js), sync or async; it may also go in `session`.
//
// onSignIn may refuse someone in the app's own words: throw an HttpError with a 4xx status (or
// any error with that status and expose not false), e.g. httpError(403, 'This account is not
// allowed to use Drop'). The password, sign-up and guest routes answer that status and message;
// the callback sends the browser to signInPage?error=<err.code, or sso_refused>&message=<it>.
// Nothing is saved, no session is set, and it is not logged as a failure.

/** The status of an app's own refusal (a 4xx it means to show), else 0. */
function refusalStatus(err) {
  const status = Number(err?.status ?? err?.statusCode);
  return Number.isInteger(status) && status >= 400 && status < 500 && err.expose !== false ? status : 0;
}
const REFUSAL_CODE = /^[a-z][a-z0-9_]{0,39}$/i;

export function createWaypoint({
  app,
  env = process.env,
  guests = 'allow',
  onSignIn,
  onClaim,
  publicUser = defaultPublicUser,
  session: sessionOpts = {},
  mountPath = '/api/auth',
  callbackPath,
  signInPage = '/login',
  returnPaths,
  password = false,
  register = true,
  guestButton = guests === 'allow',
  claim = false,
  appName,
  limits = {},
  timeoutMs = 10_000,
  fetchImpl,
  isAdmin: adminHook,
} = {}) {
  if (guests !== 'allow' && guests !== 'refuse') throw new Error("guests must be 'allow' or 'refuse'");
  if (typeof onSignIn !== 'function') throw new Error('createWaypoint needs onSignIn(waypointUser, { req, how }) => the account');
  if (claim && guests !== 'allow') throw new Error('claim needs guests: allow');
  const callback = callbackPath ?? `${mountPath}/sso/callback`;
  const STATE = hostCookie(app, 'oauth_state');
  const NEXT = hostCookie(app, 'oauth_next');
  const client = waypointClient({ env, timeoutMs, ...(fetchImpl ? { fetchImpl } : {}) });

  const session = createSession({
    app,
    env,
    ...sessionOpts,
    // the app's own admins (isAdmin here or in session), else ADMIN_CENTRAL_USER_IDS
    isAdmin: adminHook ?? sessionOpts.isAdmin,
    async onRenew(user, req) {
      if (sessionOpts.onRenew) await sessionOpts.onRenew(user, req);
      if (user.is_guest && guests === 'allow') client.reportSeen(user.central_user_id); // not waited for; never throws
    },
  });
  const sessionSecret = () => sessionOpts.secret || env.SESSION_SECRET || env.JWT_SECRET;
  /** Sign-in works only with all of these; without them the routes answer 503 and /config
   *  says so, so the page can hide the button. */
  const ready = () => client.configured() && Boolean(sessionSecret());

  // Where Waypoint sends the browser back. APP_BASE_URL pins one address; unset, it is the
  // address the request came to (https behind the proxy), so a sign-in started on the front
  // door's name returns there and one on the platform's name returns there, each to the state
  // cookie it set. Waypoint takes only callbacks registered for this app.
  const baseUrl = (req) => (String(env.APP_BASE_URL || '').trim() || `${req.protocol}://${req.get('host')}`).replace(/\/+$/, '');
  const redirectUri = (req) => `${baseUrl(req)}${callback}`;
  const pickNext = (value) => (returnPaths ? (returnPaths.includes(value) ? value : '/') : safeNext(value));
  /** The sign-in page with ?error=<code> (and anything else to say), for a sign-in that did not finish. */
  const signInPageWith = (params) => `${signInPage}${signInPage.includes('?') ? '&' : '?'}${new URLSearchParams(params)}`;
  const fail = (res, code, more = {}) => res.redirect(signInPageWith({ error: code, ...more }));
  const notReady = (res) => res.status(503).json({ error: 'Sign-in is not configured' });

  const lim = (name, windowMs, max, message, onLimit) => rateLimit({ windowMs, max, message, onLimit, ...(limits[name] || {}) });
  const signInLimit = lim('signIn', 15 * MINUTE, 10, 'Too many sign-in attempts from here. Wait a few minutes and try again.');
  const claimLimit = lim('claim', 15 * MINUTE, 10, 'Too many attempts from here. Wait a few minutes and try again.');
  // every code exchange is a call to Waypoint from this app's one address; the return lands in
  // the browser, so a refusal is the sign-in page with a message, not JSON
  const callbackLimit = lim('callback', 15 * MINUTE, 20, 'Too many sign-in attempts.', (req, res) => fail(res, 'sso_busy'));
  // Waypoint's own guest button allows a few an hour per address and its proxy route a few
  // hundred an hour for the whole app: one address must not use much of that. A slot is taken
  // before asking Waypoint and given back when no guest came of it.
  const guestSlots = limiter({ windowMs: 60 * MINUTE, max: 15, ...(limits.guest || {}) });

  const json = express.json({ limit: '16kb' });
  const unreachable = (res, what, err) => {
    console.error(`${what}: Waypoint unreachable:`, err?.message ?? err);
    res.status(502).json({ error: 'Could not reach the sign-in service. Try again shortly.' });
  };

  /** The app's half of a sign-in: its row, then the session. Answers for itself, so a database
   *  failure here is not reported as Waypoint's. Returns the account, or null once it answered. */
  async function signInHere(req, res, wu, how) {
    try {
      const user = await onSignIn(wu, { req, how });
      if (!user) throw new Error('onSignIn returned no account');
      session.set(res, user);
      return { ...user, is_admin: await session.isAdmin(user) };
    } catch (err) {
      // the app said no, in its own words: those go to the page
      const refused = refusalStatus(err);
      if (refused) {
        res.status(refused).json({ error: err.message || 'You cannot sign in here.' });
        return null;
      }
      console.error(`Sign-in (${how}): Waypoint answered, saving the account here failed:`, err?.message ?? err);
      res.status(500).json({ error: 'Could not sign you in. Try again.' });
      return null;
    }
  }

  async function handleCallback(req, res) {
    if (!ready()) return res.status(503).type('text/plain').send('Sign-in is not configured');
    const code = typeof req.query.code === 'string' ? req.query.code : '';
    const state = typeof req.query.state === 'string' ? req.query.state : '';
    const expected = readCookie(req, STATE);
    const next = pickNext(readCookie(req, NEXT));
    res.clearCookie(STATE, cookieOpts());
    res.clearCookie(NEXT, cookieOpts());
    if (!code || !state || !expected || state !== expected) return fail(res, 'sso_state');
    let r;
    try {
      r = await client.exchange(code, redirectUri(req));
    } catch (err) {
      console.error('Sign-in callback: Waypoint unreachable:', err?.message ?? err);
      return fail(res, 'sso_error');
    }
    if (r.status !== 200) return fail(res, 'sso_exchange');
    if (!r.json?.central_user_id) return fail(res, 'sso_user');
    const wu = waypointUser(r.json);
    // a no-guest app refuses before it saves a row or a session
    if (wu.is_guest && guests === 'refuse') {
      return res.status(403).type('html').send(plainPage({
        title: appName || 'Sign in',
        heading: GUEST_REFUSED,
        // back to the sign-in page, which holds on an ?error: a page that goes straight to
        // Waypoint would otherwise send the guest round to this refusal again
        links: [[`${mountPath}/sso/login?prompt=login`, 'Sign in with your own account'], [signInPageWith({ error: 'sso_guest' }), `Back to ${appName || 'the site'}`]],
      }));
    }
    let user;
    try {
      user = await onSignIn(wu, { req, how: 'sso' });
      if (!user) throw new Error('onSignIn returned no account');
    } catch (err) {
      if (refusalStatus(err)) {
        const code = REFUSAL_CODE.test(String(err.code ?? '')) ? String(err.code) : 'sso_refused';
        return fail(res, code, err.message ? { message: String(err.message).slice(0, 300) } : {});
      }
      console.error('Sign-in callback: saving the account failed:', err?.message ?? err);
      return fail(res, 'sso_save');
    }
    session.set(res, user);
    res.redirect(next);
  }

  let warned = false;
  const router = express.Router();
  router.use((req, _res, next) => {
    if (!warned && req.app?.get?.('trust proxy') === true) {
      warned = true;
      console.error("fleet-kit: trust proxy is true; set it to 1, or every limit counts an address the client wrote");
    }
    next();
  });

  // /logout, /guest, /login, /register and /claim come from the app's own pages, whether or not
  // the app guards the rest of its API. Waypoint's return is a GET, so it passes.
  router.use(sameOriginWrites());

  // What the sign-in page needs before anyone is signed in: whether sign-in is set up (it hides
  // the button otherwise) and where Waypoint lives (for its account page). Nothing secret.
  router.get('/config', (_req, res) => {
    res.json({ ssoEnabled: ready(), accountUrl: ready() ? client.url() : null, guests });
  });

  router.get('/sso/login', (req, res) => {
    if (!ready()) return res.status(503).type('text/plain').send('Sign-in is not configured');
    const state = crypto.randomBytes(16).toString('hex');
    res.cookie(STATE, state, cookieOpts({ maxAge: STATE_TTL_MS }));
    const next = pickNext(req.query.next);
    if (next !== '/') res.cookie(NEXT, next, cookieOpts({ maxAge: STATE_TTL_MS }));
    else res.clearCookie(NEXT, cookieOpts());
    // ?prompt=login (Switch account) or ?prompt=create (Create an account: Waypoint's sign-up
    // form), spelled exactly; anything else is a plain sign-in. Nothing about the person goes
    // on Waypoint's address.
    res.redirect(client.authorizeUrl({ redirectUri: redirectUri(req), state, prompt: req.query.prompt, guests }));
  });

  router.get('/sso/callback', callbackLimit, wrap(handleCallback));

  router.get('/me', wrap(async (req, res) => {
    res.set('Cache-Control', 'no-store');
    const r = await session.resolve(req, res);
    if (r.failed) return res.status(500).json({ error: 'Could not check your session. Try again.' });
    // a session in use stays alive: once a day, /me (which every page load asks) renews it
    if (r.user) await session.renew(req, res);
    else if (readCookie(req, session.name)) res.clearCookie(session.name, cookieOpts());
    res.json({ ssoEnabled: ready(), accountUrl: ready() ? client.url() : null, guests, user: r.user ? await publicUser(r.user, req) : null });
  }));

  // Signing out ends the session on the server too, when the app counts token_version
  // (session.onSignOut); the cookie is cleared only once that is done.
  router.post('/logout', wrap(async (req, res) => {
    try {
      await session.signOut(req, res);
    } catch (err) {
      console.error('Sign-out failed:', err?.message ?? err);
      return res.status(500).json({ error: 'Could not sign out. Try again.' });
    }
    res.json({ ok: true });
  }));

  // "Sign out of all games": the page signs out here first (POST /logout), then comes here for
  // Waypoint's own sign-out page. This changes nothing on its own, so a link from elsewhere is
  // harmless. return_to (an http(s) address) is passed on; Waypoint decides whether to follow it.
  router.get('/logout-all', (req, res) => {
    if (!client.configured()) return res.redirect('/');
    const back = typeof req.query.return_to === 'string' && /^https?:\/\/[^\s]+$/.test(req.query.return_to) ? req.query.return_to : null;
    res.redirect(client.logoutUrl(back));
  });

  if (guests === 'allow' && guestButton) {
    // One-click guest: a real central guest account (its own row at Waypoint, never a shared
    // login) and a session for it, with no redirect and no form.
    router.post('/guest', wrap(async (req, res) => {
      if (!ready()) return notReady(res);
      const slot = guestSlots.hit(clientKey(req));
      if (!slot.ok) {
        res.set('Retry-After', String(slot.retryAfter));
        return res.status(429).json({ error: 'Too many new guests from here right now. Try again later.' });
      }
      let minted = false;
      try {
        let r;
        try {
          r = await client.guest();
        } catch (err) {
          return unreachable(res, 'Guest sign-in', err);
        }
        if ((r.status !== 200 && r.status !== 201) || !r.json?.central_user_id) {
          if (r.status === 429) return res.status(429).json({ error: 'Too many new guests right now. Try again later.' });
          if (r.status >= 500) return res.status(502).json({ error: 'The sign-in service is having trouble. Try again shortly.' });
          return res.status(400).json({ error: r.json?.error || 'Could not start a guest session' });
        }
        const user = await signInHere(req, res, waypointUser(r.json, { guest: true }), 'guest');
        if (!user) return undefined;
        minted = true;
        res.json({ user: await publicUser(user, req) });
      } finally {
        if (!minted) slot.undo();
      }
    }));
  }

  if (password) {
    router.post('/login', signInLimit, json, wrap(async (req, res) => {
      if (!ready()) return notReady(res);
      const { email, password: pw } = req.body ?? {};
      if (typeof email !== 'string' || !email || typeof pw !== 'string' || !pw) return res.status(400).json({ error: 'Email or username, and password, are required' });
      let r;
      try {
        r = await client.login(email, pw);
      } catch (err) {
        return unreachable(res, 'Password sign-in', err);
      }
      if (r.status !== 200 || !r.json?.central_user_id) {
        const [code, error] = refusal(r, 'Wrong email, username or password');
        return res.status(code).json({ error });
      }
      const wu = waypointUser(r.json);
      if (wu.is_guest && guests === 'refuse') return res.status(403).json({ error: GUEST_REFUSED });
      const user = await signInHere(req, res, wu, 'password');
      if (user) res.json({ user: await publicUser(user, req) });
    }));

    // register: false takes sign-up away in every spelling; a route in front of this mount can't
    if (register) router.post('/register', signInLimit, json, wrap(async (req, res) => {
      if (!ready()) return notReady(res);
      const { username, password: pw } = req.body ?? {};
      const email = typeof req.body?.email === 'string' && req.body.email.trim() ? req.body.email.trim() : null;
      if (typeof username !== 'string' || !username.trim() || typeof pw !== 'string' || !pw) return res.status(400).json({ error: 'A username and a password are required' });
      // 'guest-' names are the system's own: a real account must not pass for a guest
      if (/^guest-/i.test(username.trim())) return res.status(400).json({ error: 'Usernames cannot start with "guest-"' });
      let r;
      try {
        // a sign-up form's names go to Waypoint too (it keeps them on the account), when given
        const name = (v) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, 100) : undefined);
        r = await client.register({ username: username.trim(), email, password: pw, first_name: name(req.body?.first_name), last_name: name(req.body?.last_name) });
      } catch (err) {
        return unreachable(res, 'Register', err);
      }
      if (r.status === 409) return res.status(409).json({ error: r.json?.error || 'An account with that email or username already exists. Sign in instead.' });
      if ((r.status !== 200 && r.status !== 201) || !r.json?.central_user_id) {
        const [code, error] = refusal(r, 'Could not create the account');
        return res.status(code === 401 ? 400 : code).json({ error });
      }
      // the recovery code comes back from Waypoint once, and is the only way back into an
      // account whose password is forgotten: it goes to the page
      const recoveryCode = r.json.recovery_code ?? null;
      const user = await signInHere(req, res, waypointUser(r.json, { guest: false }), 'register');
      if (user) res.status(201).json({ user: await publicUser(user, req), recovery_code: recoveryCode });
    }));
  }

  if (claim) {
    // Keep a guest account: Waypoint turns the guest into a real account under the same central
    // id, so everything it made stays where it is; here the row takes its new name.
    router.post('/claim', claimLimit, json, wrap(async (req, res) => {
      if (!ready()) return notReady(res);
      const s = await session.resolve(req, res);
      if (s.failed) return res.status(500).json({ error: 'Could not check your session. Try again.' });
      if (!s.user) return res.status(401).json({ error: 'Not signed in' });
      if (!s.user.is_guest) return res.status(409).json({ error: 'This is already a full account' });
      const { username, password: pw } = req.body ?? {};
      const email = typeof req.body?.email === 'string' && req.body.email.trim() ? req.body.email.trim() : null;
      if (typeof username !== 'string' || !username.trim() || typeof pw !== 'string' || !pw) return res.status(400).json({ error: 'Choose a username and a password' });
      if (/^guest-/i.test(username.trim())) return res.status(400).json({ error: 'Usernames cannot start with "guest-"' });
      let r;
      try {
        r = await client.claim({ central_user_id: s.user.central_user_id, username: username.trim(), password: pw, email });
      } catch (err) {
        return unreachable(res, 'Claim', err);
      }
      if (r.status !== 200 || !r.json?.central_user_id) {
        if (r.status === 404) return res.status(410).json({ error: 'This guest account is too old to keep: the sign-in service has already let it go. It still works in this browser.' });
        if (r.status === 429) return res.status(429).json({ error: 'Too many attempts. Wait a few minutes and try again.' });
        if (r.status >= 500) return res.status(502).json({ error: 'The sign-in service is having trouble. Try again shortly.' });
        return res.status(r.status === 409 ? 409 : 400).json({ error: r.json?.error || 'Could not keep the account' });
      }
      // Waypoint keeps the account under the guest's own central id. An answer that names any
      // other id is not this guest's account: nothing is saved, no session is minted for it, and
      // its recovery code never reaches this browser.
      const guestId = String(s.user.central_user_id);
      if (String(r.json.central_user_id) !== guestId) {
        console.error(`Claim: Waypoint answered for central id ${r.json.central_user_id}, not this guest's (${guestId}); refused`);
        return res.status(502).json({ error: 'The sign-in service answered for a different account. Nothing was changed here; try again shortly.' });
      }
      // Waypoint answers a claim with the account's recovery code, once (its contract). An answer
      // without one is not a finished claim: nothing is saved here, and the person is told how to
      // get in if Waypoint did keep the account.
      if (typeof r.json.recovery_code !== 'string' || !r.json.recovery_code.trim()) {
        console.error(`Claim: Waypoint's answer for central id ${guestId} carried no recovery code; refused`);
        return res.status(502).json({ error: 'The sign-in service gave an incomplete answer. If the account was kept, sign in with the name and password you chose.' });
      }
      // From here the account IS kept at Waypoint, and the recovery code exists nowhere else:
      // it goes back to the page whatever happens to the row here.
      const recoveryCode = r.json.recovery_code;
      const wu = waypointUser(r.json, { guest: false });
      let user = { ...s.user, username: wu.username, email: wu.email, is_guest: false };
      try {
        const saved = (onClaim ? await onClaim(s.user, wu, { req }) : await onSignIn(wu, { req, how: 'claim' })) || user;
        // the session only ever names this guest's own central id, whatever the app's hook returned
        if (saved.central_user_id != null && String(saved.central_user_id) !== guestId) {
          throw new Error(`the account returned names central id ${saved.central_user_id}, not ${guestId}`);
        }
        user = saved;
        session.set(res, user); // the name in the session changed
      } catch (err) {
        // the next sign-in with the new name and password brings the row into line
        console.error('Claim: Waypoint kept the account, updating it here failed:', err?.message ?? err);
      }
      res.json({ user: await publicUser({ ...user, is_admin: await session.isAdmin(user) }, req), recovery_code: recoveryCode });
    }));
  }

  /** /api/admin's gate on its own: 401 signed out, 403 anyone but the admin, 500 when the row
   *  could not be read. */
  const requireAdmin = wrap(async (req, res, next) => {
    res.setHeader?.('Cache-Control', 'no-store'); // what it lets through is private
    const r = await session.resolve(req, res);
    if (r.failed) return res.status(500).json({ error: 'Could not check your session. Try again.' });
    if (!r.user) return res.status(401).json({ error: 'Not signed in' });
    if (!r.user.is_admin) return res.status(403).json({ error: 'Admin access required' });
    next();
  });

  return {
    router,
    /** The callback handler, for an app whose registered redirect_uri is not under mountPath
     *  (pass callbackPath and mount this there: app.get(callbackPath, wp.callback)). */
    callback: [callbackLimit, wrap(handleCallback)],
    session,
    client,
    configured: ready,
    redirectUri,
    /** Whether an account is the site admin, without waiting: the list, or a synchronous isAdmin
     *  hook's answer. An async hook cannot answer here (no): use req.user.is_admin, which the
     *  session sets, or await wp.session.isAdmin(user). */
    isAdmin: (user) => session.isAdminNow(user),
    requireUser: session.requireUser,
    requireAdmin,
    adminPage: (opts = {}) => adminPage({ session, signInPath: `${mountPath}/sso/login`, appName, ...opts }),
  };
}
